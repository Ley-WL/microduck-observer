import { ref, computed, watch, onScopeDispose } from "vue";
import { defineStore } from "pinia";
import { useTelemetry } from "./store";
import { calibrationKey, loadCalibration } from "./savedCalibration";
import { levelReference } from "./calibration";
import { validQuaternion } from "./protocol";

export const useBoardCalibration = defineStore("board-calibration", () => {
  const telemetry = useTelemetry();
  const data = ref<any>(null), ready = ref(false), saving = ref(false), error = ref("");
  let generation = 0, loading = false;
  let writes: Promise<void> = Promise.resolve();
  const base = () => telemetry.endpoint.replace(/\/$/, "");
  async function request(url: string, options?: RequestInit) {
    const response = await fetch(url, { ...options, signal: AbortSignal.timeout(5000) });
    const value = await response.json();
    if (!response.ok) throw new Error(value.detail || "主板标定保存失败");
    if (value.schema !== 1 || !Number.isInteger(value.revision) || !value.joints || !value.imu) throw new Error("主板标定格式不兼容");
    return value;
  }
  async function refresh() {
    if (loading || saving.value) return;
    loading = true; const id = generation, url = base();
    try { const result = await request(url + "/api/v1/calibration"); if (id === generation) { if (!data.value || result.deviceId !== data.value.deviceId || result.revision >= data.value.revision) data.value = result; ready.value = true; error.value = ""; } }
    catch (e) { if (id === generation) error.value = String(e); }
    finally { if (id === generation) loading = false; }
  }
  function write(make: (current: any) => any, migrate = false) {
    const id = generation, url = base();
    const run = async () => {
      if (id !== generation || !ready.value) return;
      saving.value = true;
      try {
        const patch = make(data.value);
        if (!Object.keys(patch).length) return;
        const result = await request(url + "/api/v1/calibration", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ revision: data.value.revision, patch, migrate }) });
        if (id === generation) { data.value = result; error.value = ""; }
      } catch (e) { if (id === generation) { error.value = String(e); const problem=error.value;
          try { const latest=await request(url+"/api/v1/calibration"); if(id===generation)data.value=latest; } catch { /* Retain last confirmed board state. */ }
          if(id===generation)error.value=problem;
        } }
      finally { if (id === generation) saving.value = false; }
    };
    writes = writes.then(run, run); return writes;
  }
  function joints(edit: (j: any) => void) {
    return write(current => { const j = JSON.parse(JSON.stringify(current.joints)); edit(j); return { joints: { references: j.references, directions: j.directions } }; });
  }
  function orientation(quaternion: number[] | null, bootId: string, time: string) {
    return write(current => {
      const { validForBoot: _, ...imu } = current.imu;
      return { imu: { ...imu, quaternion, bootId, time } };
    });
  }
  function levelContextError(current: any): string {
    if (telemetry.connection !== "在线") return "主板未连接";
    if (telemetry.paused) return "请先恢复实时姿态";
    const sample = telemetry.orientation;
    if (!sample?.valid || !validQuaternion(sample.data?.quaternion) || !Number.isFinite(telemetry.age) || telemetry.age > 500)
      return "等待新鲜的实时 IMU 数据";
    if (sample.bootId !== current?.bootId) return "IMU 会话正在同步";
    if (!validQuaternion(current?.imu?.quaternion)) return "请先保存 IMU 参考";
    if (!telemetry.sensorOnly && !validQuaternion(current?.imu?.mountingQuaternion)) return "缺少 IMU 安装方向标定";
    const control = telemetry.system?.data.servoControl?.state;
    if (control && !["idle", "holding", "commanded", "configured", "enabled", "disabled", "failed"].includes(control))
      return "请先停止模型或姿势切换，再矫正角度";
    return "";
  }
  const levelDisabledReason = computed(() => !ready.value ? "主板标定正在加载" : saving.value ? "标定正在保存" : levelContextError(data.value));
  function levelOrientation() {
    return write(current => {
      const reason = levelContextError(current);
      if (reason) throw new Error(reason);
      const sample = telemetry.orientation!;
      const fallback = telemetry.sensorOnly ? [0,0,Math.sin(-(current.mounting?.yaw ?? -90)*Math.PI/360),Math.cos(-(current.mounting?.yaw ?? -90)*Math.PI/360)] : undefined;
      const { validForBoot: _, ...imu } = current.imu;
      return { imu: { ...imu, quaternion: levelReference(current.imu.quaternion, sample.data.quaternion,
        current.imu.mountingQuaternion ?? fallback, current.imu.targetQuaternion),
        bootId: sample.bootId, time: new Date().toLocaleString("zh-CN", { hour12:false }) } };
    });
  }
  function confirmReference(bootId: string) {
    return write(current => {
      const { validForBoot: _validForBoot, ...imu } = current.imu;
      return { imu: { ...imu, bootId } };
    });
  }
  function mounting(yaw: number) {
    if (![0, -90, 90].includes(yaw)) return;
    return write(current => ({ mounting: { ...current.mounting, yaw } }));
  }
  function installation(positionMm: number[], mountingQuaternion: number[], expectedRevision: number) {
    return write(current => {
      if (current.revision !== expectedRevision) throw new Error("标定已改变，请关闭并重新打开安装设置");
      const { validForBoot: _, ...imu } = current.imu;
      return { mounting: { ...current.mounting, positionMm },
        imu: { ...imu, mountingQuaternion, ...(JSON.stringify(imu.mountingQuaternion) === JSON.stringify(mountingQuaternion) ? {} : { mountingSamples: {}, mountingSamplesMethod: undefined }) } };
    });
  }
  let migrationKey = "";
  function migrateLegacy() {
    if (!ready.value || !data.value || saving.value) return;
    const patch: any = {};
    if (!data.value.joints.initialized && telemetry.joints?.source === "hardware") {
      const saved = loadCalibration(calibrationKey("joints", [base(), "hardware"]));
      if (saved && (Object.keys(saved.references || {}).length || Object.keys(saved.directions || {}).length)) patch.joints = { references: saved.references || {}, directions: saved.directions || {} };
    }
    const sample = telemetry.orientation;
    if (!data.value.imu.initialized && sample?.source === "hardware" && sample.bootId === data.value.bootId) {
      const saved = loadCalibration(calibrationKey("imu", [base(), sample.bootId, sample.data.frame, sample.source]));
      if (Array.isArray(saved?.quaternion)) patch.imu = { quaternion: saved.quaternion, bootId: sample.bootId, time: saved.time || "" };
    }
    const key=base()+JSON.stringify(patch);
    if (!Object.keys(patch).length || key===migrationKey) return;
    migrationKey=key;
    void write(current=>Object.fromEntries(Object.entries(patch).filter(([section])=>!current[section].initialized)),true);
  }
  watch(() => telemetry.endpoint, () => { generation++; loading=false; data.value=null; ready.value=false; saving.value=false; error.value=""; migrationKey=""; void refresh(); }, { immediate:true });
  watch([data, () => telemetry.joints?.source, () => telemetry.orientation?.bootId], migrateLegacy);
  let restoredSession = "";
  watch([data, () => telemetry.orientation, ready], () => {
    const sample = telemetry.orientation;
    if (!ready.value || saving.value || !data.value?.imu?.quaternion ||
        !sample?.valid || sample.source !== "hardware" || sample.bootId !== data.value.bootId ||
        data.value.imu.bootId === sample.bootId) return;
    const key = base() + data.value.deviceId + sample.bootId;
    if (restoredSession === key) return;
    restoredSession = key;
    void confirmReference(sample.bootId);
  });
  const timer=setInterval(()=>{void refresh();},1500);onScopeDispose(()=>clearInterval(timer));
  return { data, ready, saving, error, refresh, joints, orientation, levelOrientation, levelDisabledReason, mounting, installation, confirmReference };
});
