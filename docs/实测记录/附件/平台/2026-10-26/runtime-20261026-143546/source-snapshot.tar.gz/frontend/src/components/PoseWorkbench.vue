<script setup lang="ts">
import { ref, computed, nextTick } from "vue";
import { useTelemetry } from "../store";
import ImuInstallation from "./ImuInstallation.vue";
import { bodyTiltDegrees } from "../calibration";
import CalibrationStudio from "./CalibrationStudio.vue";
import RobotView from "./RobotView.vue";
import SignalChart from "./SignalChart.vue";
import ServoPanel from "./ServoPanel.vue";
import ModelControlPanel from "./ModelControlPanel.vue";
import { useJointPose } from "../jointPose";
import { useBoardCalibration } from "../boardCalibration";
const installationOpen = ref(false);
const board = useBoardCalibration();
const jointPose = useJointPose();
const calibrationDialog=ref<HTMLDialogElement>();
const calibrationOpen=ref(false), calibrationBusy=ref(false), calibrationDone=ref(false);
async function openCalibration(){
  calibrationDone.value=false;calibrationOpen.value=true;
  await nextTick();calibrationDialog.value?.showModal();
}
function closeCalibration(){
  if(calibrationBusy.value)return;
  calibrationDialog.value?.close();calibrationOpen.value=false;
}
function completed(){
  calibrationBusy.value=false;calibrationDone.value=true;
  calibrationDialog.value?.close();calibrationOpen.value=false;
}

const props = defineProps<{
  modelOrientation: number[] | null;
  quaternion: number[] | null;
  angles: number[] | null;
  calibrated: boolean;
  calibrationTime: string;
  canCalibrate: boolean;
  calibrationSaveError: boolean;
  mountingYaw: number;
}>();
defineEmits<{ calibrate: []; clear: []; pause: []; mounting: [value: number]; confirmReference: [] }>();
const state = useTelemetry();
const zeroPending = ref(false), homePending = ref(false), zeroMessage = ref('');
const zeroDisabled = computed(() => zeroPending.value || homePending.value || !board.ready || state.joints?.source !== 'hardware'
  || state.jointsAge >= 500 || ['preflight', 'moving', 'policy', 'disabling'].includes(state.system?.data.servoControl?.state)
  || [10,11,12,13,14,20,21,22,23,24,30,31,32,33,34].some(id => !Number.isFinite(board.data?.joints.references[String(id)])));
async function zeroJoints() {
  if (zeroDisabled.value) return;
  const endpoint = state.endpoint.replace(/\/$/, ''), boot = state.joints?.bootId;
  zeroPending.value = true; zeroMessage.value = '';
  try {
    const response = await fetch(endpoint + '/api/v1/servos/zero', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ confirmCalibration: true, revision: board.data?.revision }),
      signal: AbortSignal.timeout(15000),
    });
    const result = await response.json();
    if (endpoint === state.endpoint.replace(/\/$/, '') && boot === state.joints?.bootId)
      zeroMessage.value = response.ok ? result.message : result.detail || '零位操作被拒绝';
  } catch (e) {
    if (endpoint === state.endpoint.replace(/\/$/, ''))
      zeroMessage.value = '零位结果未确认，请检查实时角度：' + (e instanceof Error ? e.message : String(e));
  } finally { zeroPending.value = false; }
}
async function homePose() {
  if (zeroDisabled.value) return;
  const endpoint = state.endpoint.replace(/\/$/, ''), boot = state.joints?.bootId;
  homePending.value = true; zeroMessage.value = '';
  try {
    const response = await fetch(endpoint + '/api/v1/policy/home', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'xgoduck', speed: 0, revision: board.data?.revision }),
      signal: AbortSignal.timeout(15000),
    });
    const result = await response.json();
    if (endpoint === state.endpoint.replace(/\/$/, '') && boot === state.joints?.bootId)
      zeroMessage.value = response.ok && result.state !== 'failed'
        ? result.message : result.detail || result.message || 'HOME 姿态操作被拒绝';
  } catch (e) {
    if (endpoint === state.endpoint.replace(/\/$/, '') && boot === state.joints?.bootId)
      zeroMessage.value = 'HOME 姿态结果未确认，请检查实时角度：' + (e instanceof Error ? e.message : String(e));
  } finally { homePending.value = false; }
}
const robot = ref<InstanceType<typeof RobotView>>();
const lastImu = computed(() => state.chart.at(-1));
const tilt = computed(() => props.quaternion ? bodyTiltDegrees(props.quaternion).toFixed(2) : "—");
const tiltDirection = computed(() => {
  if (!props.angles) return "等待姿态数据";
  const [roll, pitch] = props.angles;
  return `${pitch >= 0 ? "前倾" : "后倾"} ${Math.abs(pitch).toFixed(2)}° · ${roll >= 0 ? "右倾" : "左倾"} ${Math.abs(roll).toFixed(2)}°`;
});
const value = (values: number[] | undefined, i: number) =>
  values?.[i]?.toFixed(2) ?? "—";
</script>
<template>
  <section class="workbench" aria-label="姿态与 IMU 单屏工作台">
    <ImuInstallation v-if="installationOpen" @close="installationOpen=false" />
    <div class="bench-toolbar">
      <div class="bench-title">
        <h1>姿态与 IMU</h1>
        <span>{{ state.info?.name || "MicroDuck" }}</span>
      </div>
      <div class="bench-live">
        <span :class="{ bad: state.poseState !== '实时' }">{{
          state.poseState
        }}</span
        ><b>{{ state.hz.toFixed(1) }} <small>Hz</small></b
        ><span
          >样本
          {{
            Number.isFinite(state.age) ? Math.round(state.age) : "—"
          }}
          ms</span
        >
      </div>
      <button class="button compact" @click="$emit('pause')">
        {{ state.paused ? "▶ 恢复显示" : "Ⅱ 暂停显示" }}
      </button>
    </div>
    <dialog ref="calibrationDialog" class="calibration-dialog" aria-label="姿态与 IMU 标定" @cancel.prevent="closeCalibration">
      <template v-if="calibrationOpen">
        <div class="dialog-toolbar"><span>姿态与 IMU · 位置标定（仰卧参考）</span><button :disabled="calibrationBusy" @click="closeCalibration">返回实时姿态 ×</button></div>
        <CalibrationStudio @busy="calibrationBusy=$event" @completed="completed" />
      </template>
    </dialog>
    <div v-if="calibrationDone" class="bench-alert" role="status">标定已保存，3D 已切回实时反馈；移动实物即可查看姿态与关节变化。</div>
    <div v-if="state.error || state.paused" class="bench-alert" role="status">
      {{ state.error || "显示已暂停 · 后台继续接收数据" }}
    </div>
    <div class="bench-grid">
      <section class="panel bench-model">
        <div class="bench-visual">
        <div class="bench-panel-head">
          <h2>3D 姿态</h2>
          <span class="subtle-tag">{{ state.source }}</span>
        </div>
        <div class="bench-model-stage">
          <RobotView
            :key="String(state.sensorOnly)"
            ref="robot"
            :quaternion="modelOrientation"
            :paused="state.paused"
          />
          <span class="bench-model-state">{{
            state.paused
              ? "显示暂停"
              : state.sensorOnly && !calibrated
                ? "参考姿态 · 待标定"
                : state.poseState === "实时"
                  ? "相对姿态 · 实时"
                  : `姿态${state.poseState}`
          }}</span>
          <button class="bench-home" @click="robot?.home()">↺ 回正视角</button>
        </div>
        <div class="bench-calibration">
          <button
            class="button compact"
            :disabled="state.paused"
            @click="openCalibration"
          >
            位置标定
          </button>
          <button class="button compact" :disabled="!!board.levelDisabledReason"
            :title="board.levelDisabledReason || '将当前姿态设为 Pitch/Roll 0°，保留航向；请先把躯干摆正。共享参考同时用于模型控制。'"
            @click="board.levelOrientation()">{{ board.saving ? '保存中…' : 'Pitch / Roll 归零' }}</button>
          <button class="button compact" :disabled="zeroDisabled" title="按已保存的位置标定，将全部15个关节（含嘴部）移动至0°并保持；请托住机器人。" @click="zeroJoints">{{ zeroPending ? '归零中…' : '零位' }}</button>
          <button class="button compact" :disabled="zeroDisabled" title="移动至当前行走模型的 HOME 姿态并保持，不启动模型推理；请托住机器人。" @click="homePose">{{ homePending ? 'HOME 到位中…' : 'HOME 姿态' }}</button>
          <button class="button compact" :disabled="!board.ready" @click="installationOpen=true">IMU 安装位置</button>
          <button
            class="text-button"
            :disabled="!calibrated || state.paused"
            @click="$emit('clear')"
          >
            清除 IMU 参考
          </button>
          <span>{{
            zeroMessage || board.error || board.levelDisabledReason || (calibrated ? "已保存到主板 " + calibrationTime : "舵机 / 硬件中位 / IMU 自由选择")
          }}</span>
        </div>
        </div>
        <div class="bench-controls">
        <ModelControlPanel />
        <label v-if="state.sensorOnly && !board.data?.imu.mountingQuaternion" class="bench-mounting">
          安装方向
          <select :value="mountingYaw" :disabled="state.paused || !canCalibrate"
            @change="$emit('mounting', Number(($event.target as HTMLSelectElement).value))">
            <option :value="-90">躯干安装修正 −90°</option>
            <option :value="0">原始传感器方向</option>
            <option :value="90">反向安装修正 +90°</option>
          </select>
          <small>安装方向保存到主板；更改后核对前倾与左倾。</small>
        </label>
        </div>
      </section>
      <section class="panel bench-imu">
        <div class="bench-panel-head">
          <h2>IMU 姿态</h2>
          <span
            class="subtle-tag"
            :class="{ bad: state.imuState !== '实时' }"
            >{{ state.imuState }}</span
          >
        </div>
        <div class="bench-angles">
          <div
            v-for="(name, i) in ['Roll 横滚', 'Pitch 俯仰', 'Yaw 偏航']"
            :key="name"
          >
            <span>{{ name }}</span
            ><strong
              >{{ angles?.[i]?.toFixed(2) ?? "—" }}<small>°</small></strong
            >
          </div>
        </div>
        <div class="bench-quaternion">
          <span>总倾角 <b>{{ tilt }}°</b> · {{ calibrated ? '相对竖直参考' : '未保存参考' }}</span>
          <span>{{ tiltDirection }}</span>
        </div>
        <div class="bench-quaternion">
          <span>{{ calibrated ? "相对" : "原始" }}四元数</span
          ><code v-for="(axis, i) in ['x', 'y', 'z', 'w']" :key="axis"
            >{{ axis }} <b>{{ quaternion?.[i]?.toFixed(3) ?? "—" }}</b></code
          >
        </div>
        <div class="bench-model-note">
          IMU 安装方向修正 · {{ jointPose.calibratedCount }} 个关节已标定跟随<br />关节与安装方向由主板保存；IMU 参考重启后自动沿用。
        </div>
        <div class="bench-axis-legend">
          <span>X</span><span>Y</span><span>Z</span><small>最近 60 秒</small>
        </div>
        <section class="bench-signal">
          <div class="bench-signal-heading">
            <h3>角速度</h3>
            <small>rad/s</small>
          </div>
          <div class="bench-axis-values">
            <b v-for="i in 3" :key="i"><small>{{ ['X', 'Y', 'Z'][i - 1] }}</small> {{ value(lastImu?.gyro, i - 1) }}</b>
          </div>
          <SignalChart :samples="state.chart" kind="gyro" />
        </section>
        <section class="bench-signal">
          <div class="bench-signal-heading">
            <h3>加速度</h3>
            <small>m/s²</small>
          </div>
          <div class="bench-axis-values">
            <b v-for="i in 3" :key="i"><small>{{ ['X', 'Y', 'Z'][i - 1] }}</small> {{ value(lastImu?.accel, i - 1) }}</b>
          </div>
          <SignalChart :samples="state.chart" kind="accel" />
        </section>
        <div class="bench-imu-note">
          原始传感器 R / P / Y
          <strong>{{
            state.angles?.map((v) => v.toFixed(1) + "°").join(" / ") || "—"
          }}</strong
          ><span>{{ board.data?.imu.mountingQuaternion ? "传感器原始坐标 · 上方为安装换算后的姿态" : "传感器坐标 · 安装矩阵未标定" }}</span>
        </div>
      </section>
      <ServoPanel compact />
    </div>
  </section>
</template>

<style>
.bench-mounting { display:flex; align-items:center; flex-wrap:wrap; gap:8px; padding:0 16px 10px; font-size:12px; }
.bench-mounting select { padding:5px 8px; border:1px solid #bccdc6; border-radius:6px; background:transparent; color:inherit; }
.bench-mounting small { color:#62786f; }
.workbench {
  height: 100%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.bench-toolbar {
  height: 44px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 18px;
}
.bench-title {
  display: flex;
  align-items: baseline;
  gap: 14px;
}
.bench-title h1 {
  font-size: 18px;
  margin: 0;
}
.bench-title > span {
  font-size: 10px;
  color: #84947d;
}
.bench-live {
  margin-left: auto;
  display: flex;
  gap: 14px;
  align-items: center;
  font-size: 10px;
  color: #829577;
}
.bench-live b {
  font-size: 16px;
  color: #456a4e;
  font-weight: 500;
}
.bench-live small {
  font-size: 9px;
}
.bench-alert {
  background: #faf0d7;
  border: 1px solid #eadcb4;
  border-radius: 4px;
  padding: 5px 10px;
  font-size: 10px;
  color: #987738;
  flex-shrink: 0;
}
.bench-grid {
  display: grid;
  grid-template-columns: minmax(0, 3fr) minmax(0, 4fr) minmax(0, 3fr);
  grid-template-areas: "imu model servos";
  gap: 10px;
  flex: 1;
  min-height: 0;
}
.bench-grid > .servo-panel { grid-area: servos; }
.bench-grid > .panel {
  margin: 0;
  min-width: 0;
  min-height: 0;
}
.bench-panel-head {
  height: 43px;
  flex-shrink: 0;
  padding: 0 13px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #e9eee4;
}
.bench-panel-head h2 {
  font-size: 12px;
}
.bench-model {
  grid-area: model;
  display: grid;
  grid-template-rows: minmax(160px, .85fr) minmax(350px, 1.15fr);
  overflow: hidden;
}
.bench-visual { display:flex;flex-direction:column;min-height:0;overflow:hidden; }
.bench-model-stage {
  position: relative;
  flex: 1 1 0;
  min-height: 0;
  background: radial-gradient(ellipse at center, #edf3e8, #fafcf7);
}
.bench-controls {
  min-height: 0;
  overflow: auto;
  container-type: size;
  border-top: 1px solid #c8dace;
}
.bench-controls .model-controls { min-height:100%;padding:6px 12px;border:0;border-radius:0; }
.bench-controls .control-heading { padding-bottom:4px; }
.bench-controls .runtime-overview { display:none; }
.bench-controls .runtime-panel { gap:4px;padding:4px 0; }
.bench-controls .pad-wrap { width:100%; }
.bench-controls .gamepad { margin-top:3px; }
.bench-controls .pad-footer { padding:2px 0; }
.bench-controls .pad-footer>span { font-size:9px; }
.bench-controls .estop { padding:6px 8px;font-size:10px;white-space:nowrap; }
.bench-controls .walk-speed-row { gap:4px; }
.bench-controls .walk-speed-row input { width:100px; }
@container(max-height:340px) {
  .bench-controls .pad-footer>span { display:none; }
  .bench-controls .pad-footer { justify-content:flex-end; }
}
.bench-model-state {
  position: absolute;
  left: 12px;
  top: 13px;
  font-size: 9px;
  color: #7b9069;
  background: #ffffffc9;
  border: 1px solid #dfe7d7;
  border-radius: 4px;
  padding: 5px 7px;
}
.bench-home {
  position: absolute;
  bottom: 10px;
  right: 12px;
  font-size: 10px;
  background: #ffffffbd;
  border: 1px solid #dce5d2;
  border-radius: 4px;
  color: #849573;
  padding: 5px 7px;
}
.bench-calibration {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  padding: 10px 12px;
  border-top: 1px solid #e9eee4;
  flex-shrink: 0;
}
.bench-calibration > span {
  font-size: 9px;
  color: #91a17f;
  flex: 1;
  min-width: 120px;
}
.bench-angles {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 5px;
  padding: 10px 12px;
  background: #f7f9f3;
  flex-shrink: 0;
}
.bench-angles span {
  display: block;
  font-size: 9px;
  color: #8b9a7c;
}
.bench-angles strong {
  font-weight: 500;
  display: block;
  font-size: 20px;
  margin-top: 6px;
  font-variant-numeric: tabular-nums;
}
.bench-angles small {
  font-size: 11px;
  color: #9caa8b;
  margin-left: 3px;
}
.bench-quaternion {
  padding: 11px 12px;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 5px;
  flex-shrink: 0;
}
.bench-quaternion > span {
  grid-column: 1/-1;
  font-size: 9px;
  color: #8d9c7f;
  margin-bottom: 3px;
}
.bench-quaternion code {
  font-size: 9px;
  color: #93a582;
}
.bench-quaternion b {
  font-weight: 500;
  color: #607b4d;
}
.bench-model-note {
  font-size: 9px;
  line-height: 1.7;
  padding: 0 12px 11px;
  color: #99a68c;
  flex-shrink: 0;
}
.bench-imu {
  grid-area: imu;
  display: flex;
  flex-direction: column;
}
.bench-axis-legend {
  display: flex;
  align-items: center;
  gap: 13px;
  padding: 12px 12px 5px;
  font-size: 10px;
  flex-shrink: 0;
}
.bench-axis-legend span:first-child,
.bench-axis-values b:first-child {
  color: #37816a;
}
.bench-axis-legend span:nth-child(2),
.bench-axis-values b:nth-child(2) {
  color: #dba855;
}
.bench-axis-legend span:nth-child(3),
.bench-axis-values b:nth-child(3) {
  color: #7196c2;
}
.bench-axis-legend small {
  margin-left: auto;
  color: #9aa78c;
  font-size: 8px;
}
.bench-signal {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  padding-top: 10px;
}
.bench-signal + .bench-signal {
  border-top: 1px solid #e9eee4;
}
.bench-signal-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  flex-shrink: 0;
}
.bench-signal-heading h3 {
  font-weight: 500;
  margin: 0;
  font-size: 11px;
}
.bench-signal-heading small {
  font-size: 9px;
  color: #99a78b;
}
.bench-axis-values {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 3px;
  padding: 10px 12px 0;
  flex-shrink: 0;
}
.bench-axis-values b {
  font-size: 14px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.bench-axis-values small { font-size: 9px; font-weight: 400; }
.bench-signal .signal-chart {
  height: auto;
  flex: 1;
  min-height: 45px;
  padding: 0;
}
.bench-imu-note {
  padding: 12px;
  font-size: 9px;
  color: #92a180;
  border-top: 1px solid #e9eee4;
  flex-shrink: 0;
}
.bench-imu-note strong {
  display: block;
  font-weight: 500;
  color: #688151;
  font-size: 11px;
  margin: 6px 0;
}
.bench-imu-note span {
  font-size: 8px;
}
@media (max-height: 720px) {
  .bench-calibration {
    padding: 7px 10px;
  }
  .bench-angles {
    padding: 8px 10px;
  }
  .bench-angles strong {
    font-size: 18px;
    margin-top: 4px;
  }
  .bench-quaternion {
    padding: 8px 10px;
  }
  .bench-model-note {
    font-size: 8px;
    padding-bottom: 7px;
  }
  .bench-panel-head {
    height: 36px;
  }
  .bench-imu-note {
    padding: 8px;
  }
  .bench-toolbar {
    height: 35px;
  }
}
@media (max-width: 1100px) {
  .bench-grid { gap: 7px; }
  .bench-title > span { display: none; }
  .bench-calibration { padding: 7px; gap: 5px; }
  .bench-axis-values { padding: 10px 7px 0; }
  .bench-axis-values b { font-size: 12px; }
  .bench-quaternion { padding: 8px; gap: 3px; }
}
</style>

<style scoped>
.calibration-dialog{width:calc(100vw - 40px);max-width:1500px;height:calc(100dvh - 32px);max-height:none;border:1px solid #bed0c1;border-radius:12px;padding:12px;background:#f4f7f1;color:#284637;box-sizing:border-box;overflow:hidden}
.calibration-dialog::backdrop{background:#102b22aa}
.dialog-toolbar{height:30px;display:flex;align-items:center;justify-content:space-between;font-size:11px}
.dialog-toolbar button{background:white;border:1px solid #c4d3c4;padding:5px 10px;border-radius:5px;color:#365e42;cursor:pointer}
.dialog-toolbar button:disabled{opacity:.4;cursor:default}
.calibration-dialog :deep(.calibration-studio){height:calc(100% - 30px)}
</style>

<style scoped>
.bench-imu .bench-angles { padding: 8px 12px; }
.bench-imu .bench-angles strong { font-size: 18px; margin-top: 4px; }
.bench-imu .bench-quaternion { padding: 7px 12px; }
.bench-imu .bench-model-note { padding: 0 12px 7px; font-size: 8px; }
.bench-imu .bench-axis-legend { padding-top: 5px; }
.bench-imu .bench-signal { padding-top: 7px; }
.bench-imu .bench-axis-values { padding-top: 6px; }
@media (max-height: 720px) {
  .bench-imu .bench-angles { padding: 5px 10px; }
  .bench-imu .bench-angles strong { font-size: 16px; }
  .bench-imu .bench-quaternion { padding: 5px 10px; }
  .bench-imu .bench-model-note { padding-bottom: 4px; }
}
</style>

<style scoped>
@media(max-height:820px){.bench-calibration{padding:6px 9px;gap:5px}.bench-calibration>span{width:auto;margin-left:auto;max-width:105px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
</style>
