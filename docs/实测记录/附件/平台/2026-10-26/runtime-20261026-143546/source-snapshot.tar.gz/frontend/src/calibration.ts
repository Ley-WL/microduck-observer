import { validQuaternion, euler } from "./protocol";
import { Quaternion } from "three";

/** Rebase pitch/roll to zero while keeping the current body yaw and installation. */
export function levelReference(reference: number[], current: number[], mounting?: number[], target?: number[]) {
  const body = bodyRelativeQuaternion(reference, current, mounting, target);
  const yaw = euler(body)[2] * Math.PI / 180;
  const desired = new Quaternion(0, 0, Math.sin(yaw / 2), Math.cos(yaw / 2));
  const m = validQuaternion(mounting) ? new Quaternion().fromArray(mounting).normalize() : new Quaternion();
  const t = validQuaternion(target) ? new Quaternion().fromArray(target).normalize() : new Quaternion();
  const relative = m.clone().multiply(t.invert()).multiply(desired).multiply(m.clone().invert());
  return new Quaternion().fromArray(current).normalize().multiply(relative.invert()).normalize().toArray();
}

/** Angle between the calibrated body's up axis and vertical, as used by policy gravity. */
export function bodyTiltDegrees(q: number[]): number {
  if (!validQuaternion(q)) throw new Error("倾角需要有效四元数");
  const n = Math.hypot(...q), [x, y] = q.map(v => v / n);
  return Math.acos(Math.max(-1, Math.min(1, 1 - 2 * (x * x + y * y)))) * 180 / Math.PI;
}

export function bodyRelativeQuaternion(reference: number[], current: number[], mounting?: number[], target?: number[]) {
  const result = new Quaternion().fromArray(relativeQuaternion(reference, current));
  if (validQuaternion(mounting)) {
    const m = new Quaternion().fromArray(mounting).normalize();
    result.premultiply(m.clone().invert()).multiply(m);
  }
  if (validQuaternion(target)) result.premultiply(new Quaternion().fromArray(target).normalize());
  return result.normalize().toArray();
}

/** Display rotation in the initial sensor frame: inverse(reference) * current.
 * This zeroes orientation only; it does not determine the sensor mounting axes.
 */
export function relativeQuaternion(
  reference: number[],
  current: number[],
): number[] {
  if (!validQuaternion(reference) || !validQuaternion(current)) {
    throw new Error("标定需要有效的单位四元数");
  }
  const a = reference.map((v) => v / Math.hypot(...reference));
  const b = current.map((v) => v / Math.hypot(...current));
  const [x, y, z, w] = [-a[0], -a[1], -a[2], a[3]];
  const [u, v, s, t] = b;
  const q = [
    w * u + x * t + y * s - z * v,
    w * v - x * s + y * t + z * u,
    w * s + x * v - y * u + z * t,
    w * t - x * u - y * v - z * s,
  ];
  const n = Math.hypot(...q);
  return q.map((value) => value / n);
}

/** Change relative sensor rotation into the robot frame: C * q * inverse(C).
 * C rotates sensor axes around +Z. Unlike subtracting Euler angles, this also
 * preserves coupled rotations and keeps the calibrated identity unchanged.
 */
export function mountingQuaternion(q: number[], yawDegrees: number): number[] {
  if (!validQuaternion(q) || ![0, -90, 90].includes(yawDegrees)) {
    throw new Error("无效的安装方向或四元数");
  }
  const n = Math.hypot(...q);
  const [x, y, z, w] = q.map((v) => v / n);
  const angle = yawDegrees * Math.PI / 180;
  return [Math.cos(angle) * x - Math.sin(angle) * y,
          Math.sin(angle) * x + Math.cos(angle) * y, z, w];
}

/** Persisted display reference may be previewed across service sessions.
 * Consumers must separately require matching boot IDs before policy inference.
 */
export function savedDisplayReference(imu: any): number[] | null {
  return validQuaternion(imu?.quaternion) ? [...imu.quaternion] : null;
}
