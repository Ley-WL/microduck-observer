<script setup lang="ts">
import { computed, ref, reactive, watch, onBeforeUnmount } from "vue";
import { latestCommand } from "../latestCommand";
import { stepAngle } from "../servoSelection";
import { watchControlIdentity } from "../controlIdentity";
import { useBoardCalibration } from "../boardCalibration";
import { useTelemetry } from "../store";
import { useJointPose } from "../jointPose";
const pose = useJointPose();
defineProps<{ compact?: boolean }>();
const state = useTelemetry();
const board = useBoardCalibration();
const limits = ref<Record<number, [number, number]>>({});
const drafts = reactive<Record<number, number | string>>({});
const pending = ref(false), message = ref(''), failed = ref(false);
const busy = computed(() => {
  const control = state.system?.data.servoControl;
  return ['preflight', 'moving', 'policy', 'disabling'].includes(control?.state) && control?.action !== 'angle';
});
const commands = latestCommand<{ id: number; angle: number; endpoint: string; boot: string | undefined; revision: number | undefined }>(async command => {
  if (!allowed(command.id) || command.endpoint !== state.endpoint || command.boot !== state.joints?.bootId || command.revision !== board.data?.revision) return;
  await sendAngle(command);
});
onBeforeUnmount(() => commands.clear());
watch(() => [state.endpoint, state.joints?.bootId, board.data?.revision, state.paused, state.connection, state.system?.data.servoControl?.state], () => {
  const control = state.system?.data.servoControl;
  if (state.paused || state.connection !== '在线' || busy.value || ['disabled', 'failed'].includes(control?.state)) commands.clear();
});
watch(() => state.endpoint, async endpoint => {
  limits.value = {}; message.value = '';
  try {
    const response = await fetch(endpoint.replace(/\/$/, '') + '/api/v1/servos/limits');
    if (!response.ok) throw new Error('角度范围加载失败');
    const data = await response.json();
    if (state.endpoint === endpoint) limits.value = data.limits;
  } catch { if (state.endpoint === endpoint) message.value = '官方角度范围未加载'; }
}, { immediate: true });
watchControlIdentity([() => state.endpoint, () => state.joints?.bootId, () => board.data?.revision], () => {
  commands.clear();
  for (const key of Object.keys(drafts)) delete drafts[Number(key)];
});
function measured(id: number) {
  const angle = pose.angles[id];
  return pose.references[id] !== undefined && pose.fresh(id) && angle != null ? angle * 180 / Math.PI : null;
}
function draft(id: number) { return drafts[id] ?? (measured(id)?.toFixed(1) ?? ''); }
function canControl(id: number) {
  return !!limits.value[id] && board.ready && !board.saving && pose.references[id] !== undefined && pose.fresh(id) && !state.paused &&
    state.joints?.source === 'hardware' && status(id) === '在线' && !busy.value;
}
function allowed(id: number) {
  const raw = draft(id), angle = Number(raw), range = limits.value[id];
  return canControl(id) && !!range && raw !== '' && Number.isFinite(angle) && angle >= range[0] && angle <= range[1];
}
function dragAngle(id: number, event: Event) {
  pose.selected = id;
  drafts[id] = Number((event.target as HTMLInputElement).value);
  queueAngle(id);
}
function canStep(id: number, delta: number) {
  const range = limits.value[id];
  return canControl(id) && !!range && stepAngle(draft(id), delta, range) !== null && stepAngle(draft(id), delta, range) !== Number(draft(id));
}
function nudge(id: number, delta: number) {
  pose.selected = id;
  if (!canStep(id, delta)) return;
  drafts[id] = stepAngle(draft(id), delta, limits.value[id]!)!;
  queueAngle(id);
}
function queueAngle(id: number) {
  if (!allowed(id)) return;
  commands.push({ id, angle: Number(draft(id)), endpoint: state.endpoint, boot: state.joints?.bootId, revision: board.data?.revision });
}
async function sendAngle(command: { id: number; angle: number; endpoint: string; boot: string | undefined; revision: number | undefined }) {
  const { id, angle, endpoint, boot, revision } = command;
  pending.value = true; failed.value = false; message.value = '';
  try {
    const response = await fetch(endpoint.replace(/\/$/, '') + '/api/v1/servos/angle', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, angleDeg: angle, revision }),
      signal: AbortSignal.timeout(10000),
    });
    const result = await response.json();
    if (endpoint !== state.endpoint || boot !== state.joints?.bootId || revision !== board.data?.revision) return;
    if (!response.ok) throw new Error(result.detail || '操作被拒绝');
    message.value = result.feedbackConfirmed === false ? result.message : '';
  } catch (error) {
    if (endpoint === state.endpoint && boot === state.joints?.bootId) {
      failed.value = true; message.value = error instanceof Error ? error.message : '未收到操作结果，请核对实时角度与使能状态';
    }
    throw error;
  } finally { pending.value = false; }
}
const rows = computed(() => state.joints?.data.servos || []);
const fresh = computed(() => state.connection === "在线" && !!state.joints?.valid && state.jointsAge < 1500);
const online = computed(() => fresh.value ? rows.value.filter((r: any) => r.online && r.ageMs + state.jointsAge < 1500) : []);
const summary = computed(() => ({
  voltage: online.value.length ? (online.value.reduce((n: number, r: any) => n+r.voltage, 0)/online.value.length).toFixed(1) : "—",
  faults: online.value.length ? online.value.filter((r: any) => r.fault !== 0).length : "—",
}));
function status(id: number) {
  if (!state.joints?.data.configuredIds.includes(id)) return "未接入";
  if (state.paused) return "已暂停";
  if (!fresh.value) return "已过期";
  const r = rows.value.find((r: any) => r.id === id);
  return !r?.online ? "无应答" : r.ageMs + state.jointsAge >= 1500 ? "已过期" : r.fault ? "异常" : "在线";
}
function value(id: number, field: string) {
  const r = online.value.find((r: any) => r.id === id);
  if (!r) return "—";
  if (field === "age") return Math.round(r.ageMs + state.jointsAge);
  if (field === "voltage") return r.voltage.toFixed(1);
  if (field === "torque") return r.torque === 0 ? "关闭" : r.torque === 1 ? "开启" : "模式 " + r.torque;
  return r[field] ?? "—";
}
// All writes go through the backend serial owner.
const groups = [
  {
    name: "左腿",
    range: "20–24",
    joints: [
      { id: 20, name: "左髋 · 偏航", axis: "yaw" },
      { id: 21, name: "左髋 · 横滚", axis: "roll" },
      { id: 22, name: "左髋 · 俯仰", axis: "pitch" },
      { id: 23, name: "左膝", axis: "" },
      { id: 24, name: "左踝", axis: "" },
    ],
  },
  {
    name: "头颈与嘴",
    range: "30–34",
    joints: [
      { id: 30, name: "颈部 · 俯仰", axis: "pitch" },
      { id: 31, name: "头部 · 俯仰", axis: "pitch" },
      { id: 32, name: "头部 · 偏航", axis: "yaw" },
      { id: 33, name: "头部 · 横滚", axis: "roll" },
      { id: 34, name: "嘴", axis: "" },
    ],
  },
  {
    name: "右腿",
    range: "10–14",
    joints: [
      { id: 10, name: "右髋 · 偏航", axis: "yaw" },
      { id: 11, name: "右髋 · 横滚", axis: "roll" },
      { id: 12, name: "右髋 · 俯仰", axis: "pitch" },
      { id: 13, name: "右膝", axis: "" },
      { id: 14, name: "右踝", axis: "" },
    ],
  },
];
</script>

<template>
  <section
    class="panel servo-panel"
    :class="{ 'servo-compact': compact }"
    aria-labelledby="servo-title"
  >
    <div class="panel-title">
      <div>
        <h2 id="servo-title">舵机反馈</h2>
        <span class="count">15 个舵机</span>
      </div>
      <span class="subtle-tag">{{ state.joints ? (state.paused ? "显示暂停" : fresh ? "实时反馈" : "反馈过期") : "反馈未接入" }}</span>
    </div>
    <div class="servo-summary">
      <div>
        <span>在线数量</span><strong>{{ state.joints ? online.length : "—" }} <small>/ 15</small></strong>
      </div>
      <div>
        <span>平均电压</span><strong>{{ summary.voltage }} <small>V</small></strong>
      </div>
      <div><span>故障数量</span><strong>{{ summary.faults }}</strong></div>
      <p>拖动即控制对应关节并使能。</p>
    </div>
    <div
      class="servo-table-scroll"
      role="region"
      aria-label="15 个舵机反馈"
      tabindex="0"
    >
      <table class="servo-table">
        <caption>
          飞特 HD-1910 · 未采集到数据的项目显示 —
        </caption>
        <thead><tr>
          <th scope="col">ID / 关节</th>
          <th scope="col">实测角度<small>°</small></th>
          <th scope="col" class="angle-heading">目标角度<small>角度范围 · °</small></th>
          <th scope="col">电压<small>V</small></th>
          <th scope="col">状态</th>
        </tr></thead>
        <tbody v-for="group in groups" :key="group.name">
          <tr class="servo-group"><th colspan="5" scope="rowgroup">{{ group.name }} <span>ID {{ group.range }} · 5 个</span></th></tr>
          <tr v-for="joint in group.joints" :key="joint.id" class="servo-row" :class="{ selected: pose.selected === joint.id }">
            <th scope="row"><button class="joint-select" :aria-label="'选择舵机 ' + joint.id + ' ' + joint.name" :aria-pressed="pose.selected === joint.id" @click="pose.selected = joint.id">
              <span class="servo-id">{{ joint.id }}</span>{{ joint.name }}<span v-if="pose.references[joint.id] !== undefined" class="joint-calibrated">●</span>
            </button></th>
            <td>{{ measured(joint.id)?.toFixed(1) ?? '—' }}<small class="position-label">{{ value(joint.id, 'position') }} 步</small></td>
            <td class="angle-cell">
              <div v-if="limits[joint.id]" class="angle-slider" :title="joint.id === 34 ? '用户确认范围：0–30°' : '官方关节范围'">
                <div class="angle-adjust">
                <button :aria-label="joint.name + '减小1度'" title="−1°，立即控制并使能" :disabled="!canStep(joint.id, -1)" @click="nudge(joint.id, -1)">−</button>
                <input type="range" step="0.1" :min="limits[joint.id]![0]" :max="limits[joint.id]![1]" :value="draft(joint.id)"
                  :aria-label="joint.name + '目标角度'" :disabled="!canControl(joint.id)"
                  @pointerdown="pose.selected = joint.id" @focus="pose.selected = joint.id"
                  @input="dragAngle(joint.id, $event)" />
                <button :aria-label="joint.name + '增大1度'" title="+1°，立即控制并使能" :disabled="!canStep(joint.id, 1)" @click="nudge(joint.id, 1)">+</button>
                </div>
                <small><span>{{ limits[joint.id]![0] }}°</span><strong>{{ draft(joint.id) }}°</strong><span>{{ limits[joint.id]![1] }}°</span></small>
              </div>
              <span v-else class="range-missing">加载范围…</span>
            </td>
            <td>{{ value(joint.id, 'voltage') }}</td>
            <td><span class="servo-unavailable" :data-status="status(joint.id)">{{ status(joint.id) }}</span><small class="torque-label">{{ value(joint.id, 'torque') }}</small></td>
          </tr>
        </tbody>
      </table>
    </div>
    <p class="angle-message" :class="{ failed }" role="status" :title="message">{{ message }}</p>
    <div class="joint-calibration" aria-label="单颗舵机显示标定">
      <div class="joint-calibration-heading">
        <strong>#{{ pose.selected }} 初始位置</strong>
        <span>{{ pose.references[pose.selected] === undefined ? '未标定' : '基准 ' + pose.references[pose.selected] + ' 步' }}</span>
        <span>Δ {{ pose.references[pose.selected] !== undefined && pose.fresh(pose.selected) ? ((pose.angles[pose.selected] ?? 0) * 180 / Math.PI).toFixed(1) + '°' : '—' }}</span>
      </div>
      <div class="joint-calibration-actions">
        <button :disabled="!pose.canCalibrate(pose.selected)" @click="pose.calibrate(pose.selected)">{{ pose.references[pose.selected] === undefined ? '标定初始位置' : '重新标定' }}</button>
        <button :disabled="state.paused" @click="pose.reverse(pose.selected)" :title="'改变标定角度方向（显示与角度控制共用），当前系数 ' + pose.direction(pose.selected)">方向 {{ pose.direction(pose.selected) === 1 ? '+' : '−' }} ↔</button>
        <button :disabled="state.paused || pose.references[pose.selected] === undefined" @click="pose.clear(pose.selected)">清除</button>
      </div>
      <p>{{ (pose.saveError ? '主板标定同步失败，请检查连接。' : '') || state.joints?.data.error || '选关节 → 摆到模型参考姿势 → 标定；保存到主板，网页与 App 共用。' }}</p>
      <p>选关节在3D中高亮；滑块或±按钮立即控制（每次1°），实测角度下方为编码器位置。</p>
    </div>
  </section>
</template>

<style scoped>
.servo-panel {
  margin-bottom: 20px;
}
.servo-summary {
  display: flex;
  align-items: center;
  gap: 32px;
  padding: 18px 20px;
  border-bottom: 1px solid #edf1e9;
  flex-wrap: wrap;
}
.servo-summary > div {
  min-width: 82px;
}
.servo-summary span {
  display: block;
  font-size: 10px;
  color: #82917b;
}
.servo-summary strong {
  display: block;
  font-size: 21px;
  font-weight: 500;
  margin-top: 7px;
}
.servo-summary small {
  font-size: 11px;
  color: #9aa58f;
  font-weight: 400;
}
.servo-summary p {
  margin: 0 0 0 auto;
  max-width: 270px;
  line-height: 1.8;
  font-size: 11px;
  color: #8c9982;
}
.servo-table-scroll {
  overflow-x: auto;
}
.servo-table {
  border-collapse: collapse;
  width: 100%;
  min-width: 0;
  text-align: left;
  font-size: 11px;
  white-space: nowrap;
}
.servo-table caption {
  text-align: left;
  font-size: 10px;
  color: #8b9980;
  padding: 12px 20px;
}
.servo-table th,
.servo-table td {
  padding: 11px 12px;
  border-bottom: 1px solid #edf1e9;
}
.servo-table th:first-child,
.servo-table td:first-child {
  padding-left: 20px;
}
.servo-table thead th {
  font-size: 10px;
  color: #819175;
  font-weight: 500;
  background: #fafbf8;
}
.servo-table thead small {
  display: block;
  font-size: 9px;
  color: #a0ab95;
  font-weight: 400;
  margin-top: 4px;
}
.servo-group th {
  background: #edf3e9;
  color: #5d7650;
  font-weight: 600;
  font-size: 11px;
}
.servo-group span {
  font-size: 9px;
  color: #96a489;
  font-weight: 400;
  margin-left: 12px;
}
.servo-row th {
  font-weight: 500;
  color: #5d7051;
}
.servo-row:hover {
  background: #fafcf7;
}
.servo-id {
  display: inline-block;
  width: 25px;
  color: #91a47d;
  font-family: Consolas, monospace;
  margin-right: 9px;
}
.servo-unavailable {
  display: inline-block;
  background: #f0f3ed;
  border: 1px solid #e3e9dd;
  border-radius: 4px;
  padding: 3px 7px;
  color: #8f9c81;
  font-size: 9px;
}
.servo-unavailable[data-status="在线"] {
  color: #166534;
  background: #dcfce7;
  border-color: #86c99b;
}
.servo-unavailable[data-status="无应答"],
.servo-unavailable[data-status="异常"] {
  color: #991b1b;
  background: #fee2e2;
  border-color: #f0a4a4;
}
.servo-unavailable[data-status="已过期"] {
  color: #92400e;
  background: #fef3c7;
  border-color: #e7bc63;
}
.servo-unavailable[data-status="已暂停"] {
  color: #1e40af;
  background: #dbeafe;
  border-color: #93b6e5;
}
.servo-unavailable[data-status="未接入"] {
  color: #5b6470;
  background: #f1f3f5;
  border-color: #d1d5db;
}
.servo-empty {
  color: #a7b09e;
}
.servo-footnote {
  padding: 13px 20px;
  font-size: 10px;
  color: #91a082;
  line-height: 1.8;
}
@media (max-width: 600px) {
  .servo-summary {
    gap: 18px;
  }
  .servo-summary p {
    margin-left: 0;
    max-width: none;
    width: 100%;
  }
}
@media (max-width: 1100px) {
  .servo-compact .servo-table th,
  .servo-compact .servo-table td { padding-left: 2px; padding-right: 2px; }
  .servo-compact .servo-table thead th:last-child { width: 16%; }
  .servo-compact .servo-unavailable { padding: 2px 1px; }
}
</style>

<style scoped>
.servo-compact {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}
.servo-compact > .panel-title {
  height: 43px;
  min-height: 0;
  padding: 0 12px;
  flex-shrink: 0;
}
.servo-compact .servo-summary {
  padding: 10px 12px;
  gap: 12px;
  justify-content: space-between;
  flex-shrink: 0;
  flex-wrap: nowrap;
}
.servo-compact .servo-summary > div {
  min-width: 0;
}
.servo-compact .servo-summary span {
  font-size: 9px;
}
.servo-compact .servo-summary strong {
  font-size: 15px;
  margin-top: 4px;
}
.servo-compact .servo-summary small {
  font-size: 9px;
}
.servo-compact .servo-summary p {
  display: none;
}
.servo-compact .servo-table-scroll {
  flex: 1;
  min-height: 0;
  overflow: visible;
}
.servo-compact .servo-table {
  height: 100%;
  min-width: 0;
  table-layout: fixed;
  font-size: 10px;
  white-space: normal;
}
.servo-compact .servo-table caption {
  display: none;
}
.servo-compact .servo-table th,
.servo-compact .servo-table td {
  padding: 0 5px;
  line-height: 1.2;
  vertical-align: middle;
  text-align: center;
}
.servo-compact .servo-table th:first-child {
  padding-left: 10px;
  text-align: left;
  width: 28%;
}
.servo-compact .servo-table th:last-child {
  width: 13%;
}
.servo-compact .servo-table thead {
  height: 37px;
}
.servo-compact .servo-table thead th {
  font-size: 9px;
}
.servo-compact .servo-table thead small {
  font-size: 8px;
  margin-top: 2px;
}
.servo-compact .servo-group {
  height: 22px;
}
.servo-compact .servo-group th {
  font-size: 9px;
}
.servo-compact .servo-group span {
  font-size: 8px;
  margin-left: 7px;
}
.servo-compact .servo-id {
  width: 16px;
  margin-right: 4px;
  font-size: 9px;
}
.servo-compact .servo-unavailable {
  font-size: 8px;
  padding: 2px 4px;
  white-space: nowrap;
}
.servo-compact .servo-footnote {
  font-size: 8px;
  line-height: 1.6;
  padding: 8px 12px;
  flex-shrink: 0;
  border-top: 1px solid #e9eee4;
}
@media (max-height: 720px) {
  .servo-compact > .panel-title {
    height: 36px;
  }
  .servo-compact .servo-summary {
    padding: 7px 10px;
  }
  .servo-compact .servo-group {
    height: 19px;
  }
  .servo-compact .servo-table thead {
    height: 31px;
  }
  .servo-compact .servo-footnote {
    padding: 5px 10px;
  }
  .servo-compact .servo-table {
    font-size: 9px;
  }
}
</style>

<style scoped>
.joint-select { border: 0; background: transparent; color: inherit; font: inherit; text-align: left; padding: 2px 0; cursor: pointer; width: 100%; }
.joint-select:focus-visible { outline: 2px solid #4f8e6c; }
.joint-calibrated { color: #16834a; font-size: 6px; margin-left: 2px; }
.servo-row.selected { background: #eaf4ee; }
.joint-calibration { flex-shrink: 0; border-top: 1px solid #dce8df; padding: 8px; background: #f8fbf8; }
.joint-calibration-heading { display: flex; justify-content: space-between; gap: 4px; font-size: 9px; color: #56715e; }
.joint-calibration-heading strong { font-weight: 600; }
.joint-calibration-actions { display: flex; gap: 5px; margin: 6px 0; }
.joint-calibration-actions button { border: 1px solid #b5ccbc; background: white; color: #315f43; border-radius: 4px; padding: 4px 6px; font-size: 10px; cursor: pointer; }
.joint-calibration-actions button:disabled { opacity: .45; cursor: default; }
.joint-calibration p { margin: 3px 0 0; font-size: 8px; color: #788978; line-height: 1.4; }
</style>

<style scoped>
.angle-heading { width: 34%; }
.angle-cell form { display: grid; grid-template-columns: minmax(0, 1fr) 30px; gap: 2px; }
.angle-cell input { min-width: 0; width: 100%; box-sizing: border-box; border: 1px solid #bfcebd; border-radius: 4px; padding: 2px; font-size: 11px; color: #315f43; background: white; }
.angle-cell button { border: 0; border-radius: 4px; background: #dceee2; color: #315f43; padding: 2px; font-size: 9px; cursor: pointer; }
.angle-cell button:disabled { opacity: .4; cursor: default; }
.angle-cell small { grid-column: 1 / -1; font-size: 8px; color: #879580; }
.range-missing { font-size: 9px; color: #879580; }
.torque-label { display: block; font-size: 8px; color: #879580; }
.angle-message { box-sizing: border-box; height: 24px; flex: 0 0 24px; margin: 0; padding: 5px 8px; font-size: 10px; line-height: 14px; color: #315f43; white-space: nowrap; overflow: auto; }
.angle-message.failed { color: #a33e2e; }
.servo-compact .servo-table th:first-child { width: 27%; }
.servo-compact .servo-table .angle-heading { width: 34%; }
</style>

<style scoped>
.angle-slider input[type="range"] { width: 100%; padding: 0; margin: 2px 0; height: 15px; accent-color: #428561; cursor: ew-resize; }
.angle-slider small { display: flex; justify-content: space-between; gap: 2px; }
.angle-slider strong { color: #315f43; font-weight: 600; }
.angle-adjust { display: grid; grid-template-columns: 18px minmax(0, 1fr) 18px; gap: 3px; align-items: center; }
.angle-adjust button { height: 19px; font-size: 13px; line-height: 1; padding: 0; }
.angle-adjust button:focus-visible { outline: 2px solid #428561; }
.position-label { display: block; color: #879580; font-size: 8px; margin-top: 2px; white-space: nowrap; }
</style>
