mod autonomy;
mod vision;
mod demo;
mod dance;
mod camera;
mod head_control;
mod gamepad;
mod pad_bindings;
mod gamepad_bluetooth;
mod calibration;
mod control;
mod ducklink;
mod ducklink_motion;
mod ducklink_protocol;
mod guided;
mod gains;
mod imu;
mod orientation;
mod policy;
mod swizzle;
mod official_roll;
mod official_fall;
mod model_registry;
mod observer_ota;
mod web_update;
mod roll_exit;
mod rear_hook;
mod walk_profile;
mod walk_handoff;
mod power;
mod quack;
mod resources;
mod servos;
mod telemetry;
mod tof;
use axum::{
    body::Bytes,
    extract::{
        ws::{Message, WebSocket, WebSocketUpgrade},
        DefaultBodyLimit, Path, Query, State,
    },
    http::{HeaderMap, HeaderValue, Method, StatusCode},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use calibration::Calibration;
use serde_json::{json, Value};
use std::{
    collections::BTreeMap,
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc, Mutex, RwLock,
    },
    time::{Duration, Instant},
};
use telemetry::{rates, Shared, Telemetry, IDS};
use tower_http::{cors::CorsLayer, services::ServeDir};
#[derive(Clone)]
struct App {
    telemetry: Shared,
    cal: Arc<Mutex<Calibration>>,
    topics: BTreeMap<String, Value>,
    hardware: bool,
    servo: bool,
    tof: bool,
    owner: Option<control::Owner>,
    gate: Arc<tokio::sync::Semaphore>,
    input_gate: Arc<tokio::sync::Semaphore>,
    plans: guided::Plans,
    shutdown: Arc<AtomicBool>,
    gamepad_debug: Arc<AtomicBool>,
}
fn error(status: StatusCode, message: &str) -> Response {
    (status, Json(json!({"detail":message}))).into_response()
}
fn check_write(headers: &HeaderMap, body: &Bytes, max: usize) -> Result<Value, Response> {
    if let Some(origin) = headers.get("origin") {
        let host = headers
            .get("host")
            .and_then(|h| h.to_str().ok())
            .unwrap_or("");
        let http = format!("http://{host}");
        if ![
            http.as_str(),
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ]
        .contains(&origin.to_str().unwrap_or(""))
        {
            return Err(error(StatusCode::FORBIDDEN, "Origin not allowed"));
        }
    }
    if headers
        .get("content-type")
        .and_then(|h| h.to_str().ok())
        .unwrap_or("")
        .split(';')
        .next()
        != Some("application/json")
    {
        return Err(error(StatusCode::UNSUPPORTED_MEDIA_TYPE, "JSON required"));
    }
    if body.len() > max {
        return Err(error(StatusCode::PAYLOAD_TOO_LARGE, "Request too large"));
    }
    let v: Value = serde_json::from_slice(body)
        .map_err(|_| error(StatusCode::UNPROCESSABLE_ENTITY, "Invalid request"))?;
    if !v.is_object() {
        return Err(error(StatusCode::UNPROCESSABLE_ENTITY, "Invalid request"));
    }
    Ok(v)
}
fn check_action(h: &HeaderMap, b: &Bytes, max: usize) -> Result<Value, Response> {
    check_write(h, b, max).map_err(|r| {
        if r.status() == StatusCode::UNPROCESSABLE_ENTITY {
            error(StatusCode::CONFLICT, "Invalid request")
        } else {
            r
        }
    })
}
// Resolve the running executable, not the mutable current symlink.
fn service_version() -> &'static Value {
    static VERSION: std::sync::OnceLock<Value> = std::sync::OnceLock::new();
    VERSION.get_or_init(|| {
        let release = std::env::current_exe().ok().and_then(|exe| {
            let bin=exe.parent()?;
            let dir=bin.parent()?;
            (bin.file_name()?=="bin" && dir.parent()?.file_name()?=="releases")
                .then(||dir.file_name()?.to_str().map(str::to_owned)).flatten()
        });
        json!({"version":env!("CARGO_PKG_VERSION"),"release":release})
    })
}
async fn info(State(a): State<App>) -> Json<Value> {
    let s = a.telemetry.read().unwrap();
    Json(
        json!({"name":if a.hardware{"MicroDuck · MS901M"}else{"MicroDuck Lab"},"imuModel":if a.hardware{json!("MS901M")}else{Value::Null},"protocolVersion":1,"service":service_version(),"bootId":s.boot,"source":s.source,"topics":a.topics,"capabilities":{"pose":!a.hardware,"imu":true,"sensorOrientation":a.hardware,"joints":a.servo,"camera":camera::available(),"tof":a.tof,"scenarios":!a.hardware}}),
    )
}
async fn health(State(a): State<App>) -> Json<Value> {
    let s = a.telemetry.read().unwrap();
    Json(
        json!({"status":if a.hardware&&s.imu_health()["state"]!="streaming"{"degraded"}else{"ok"},"source":s.source,"imu":s.imu_health(),"bluetooth":s.ble_health,"tof":if a.tof{s.tof_health()}else{Value::Null},"joints":s.latest.get("joints").map(|v|s.stamp(v)),"logCount":s.logs.len()}),
    )
}
async fn power_action(State(a): State<App>, Path(action): Path<String>, headers: HeaderMap, body: Bytes) -> Response {
    let value = match check_write(&headers, &body, 256) { Ok(v) => v, Err(r) => return r };
    if !a.hardware || !power::enabled() {
        return error(StatusCode::FORBIDDEN, "当前设备未启用电源控制");
    }
    let boot = a.telemetry.read().unwrap().boot.clone();
    if !power::validate(&action, &value, &boot) {
        return error(StatusCode::CONFLICT, "请重新连接当前主板并确认关机或重启");
    }
    match tokio::time::timeout(Duration::from_secs(3), power::request(&action)).await {
        Ok(Ok(v)) => (StatusCode::ACCEPTED, Json(v)).into_response(),
        Ok(Err(e)) => error(StatusCode::SERVICE_UNAVAILABLE, &format!("电源请求失败：{e}")),
        Err(_) => error(StatusCode::SERVICE_UNAVAILABLE, "电源请求结果未确认，请检查主板状态，勿直接断电"),
    }
}
async fn snapshot(State(a): State<App>) -> Json<Value> {
    let s = a.telemetry.read().unwrap();
    let mut out: BTreeMap<String, Value> = s
        .latest
        .iter()
        .map(|(k, v)| (k.clone(), s.stamp(v)))
        .collect();
    out.insert("calibration".into(), a.cal.lock().unwrap().read(&s.boot));
    Json(json!(out))
}
async fn get_cal(State(a): State<App>) -> Json<Value> {
    let boot = a.telemetry.read().unwrap().boot.clone();
    Json(a.cal.lock().unwrap().read(&boot))
}
async fn set_cal(State(a): State<App>, h: HeaderMap, b: Bytes) -> Response {
    let v = match check_write(&h, &b, 16384) {
        Ok(v) => v,
        Err(r) => return r,
    };
    let _permit = match a.gate.clone().try_acquire_owned() {
        Ok(p) => p,
        Err(_) => return error(StatusCode::CONFLICT, "舵机或标定任务运行中，请先停止模型"),
    };
    let boot = a.telemetry.read().unwrap().boot.clone();
    let mut c = a.cal.lock().unwrap();
    if let Err(e) = calibration::validate(&v["patch"]) {
        return error(StatusCode::UNPROCESSABLE_ENTITY, &e.to_string());
    }
    match c.update(&v["revision"], &v["patch"], &boot, v["migrate"] == true) {
        Ok(v) => Json(v).into_response(),
        Err(e) => error(StatusCode::CONFLICT, &e.to_string()),
    }
}
async fn limits() -> Json<Value> {
    let map: BTreeMap<String, Value> = IDS
        .iter()
        .map(|id| (id.to_string(), json!(telemetry::limit(*id).unwrap())))
        .collect();
    Json(json!({"limits":map,"unit":"deg","source":"kissqy-hd1910-saved-mechanical-v1","targetEncoding":"mechanical-clamp-single-turn-reject-v1"}))
}
async fn poses() -> Json<Value> {
    Json(serde_json::from_str(include_str!("poses.json")).expect("bundled poses"))
}
async fn guided_action(
    State(a): State<App>,
    Path(action): Path<String>,
    h: HeaderMap,
    b: Bytes,
) -> Response {
    if !["preview", "execute"].contains(&action.as_str()) {
        return error(StatusCode::NOT_FOUND, "Not Found");
    }
    let body = match check_action(&h, &b, 16384) {
        Ok(v) => v,
        Err(r) => return r,
    };
    let permit = match a.gate.clone().try_acquire_owned() {
        Ok(p) => p,
        Err(_) => return error(StatusCode::CONFLICT, "已有标定或运动任务正在执行"),
    };
    // A browser disconnect does not drop the lock while EEPROM can still write.
    let task = tokio::spawn(async move {
        let _permit = permit;
        if action == "preview" {
            guided::preview(&body, &a.telemetry, &a.cal, &a.plans).await
        } else if body["confirm"] != true {
            Err(anyhow::anyhow!("请确认姿势和写入预览"))
        } else {
            guided::execute(
                &body["token"],
                &a.telemetry,
                &a.cal,
                &a.plans,
                a.owner.as_ref(),
            )
            .await
        }
    });
    match task.await {
        Ok(Ok(v)) => Json(v).into_response(),
        Ok(Err(e)) => error(StatusCode::CONFLICT, &e.to_string()),
        Err(e) => error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}
async fn servo_action(
    State(a): State<App>,
    Path(action): Path<String>,
    h: HeaderMap,
    b: Bytes,
) -> Response {
    if !["enable", "disable", "stand", "zero", "angle", "profile", "quack"].contains(&action.as_str()) {
        return error(StatusCode::NOT_FOUND, "Not Found");
    }
    let v = match check_action(&h, &b, 1024) {
        Ok(v) => v,
        Err(r) => return r,
    };
    let Some(owner) = a.owner.as_ref() else {
        return error(StatusCode::CONFLICT, "未连接实机舵机服务");
    };
    let permit = if action == "disable" {
        None
    } else {
        match a.gate.clone().try_acquire_owned() {
            Ok(p) => Some(p),
            Err(_) => return error(StatusCode::CONFLICT, "已有标定或运动任务正在执行"),
        }
    };
    let boot = a.telemetry.read().unwrap().boot.clone();
    let cal = a.cal.lock().unwrap().read(&boot);
    if ["stand", "zero", "angle", "quack"].contains(&action.as_str()) && v["revision"] != cal["revision"] {
        return error(StatusCode::CONFLICT, "标定已更新，请刷新后重试");
    }
    if matches!(action.as_str(), "stand" | "zero")
        && (v["confirmCalibration"] != true
            || IDS[..if action == "zero" { 15 } else { 14 }]
                .iter()
                .any(|id| cal["joints"]["references"].get(id.to_string()).is_none()))
    {
        return error(
            StatusCode::CONFLICT,
            "请确认位置标定正确并完成所有目标关节标定",
        );
    }
    if ["angle", "profile"].contains(&action.as_str()) {
        let degrees = if action == "angle" {
            v["angleDeg"].clone()
        } else {
            json!(0)
        };
        if let Err(e) = control::angle_request(&v["id"], &degrees) {
            return error(StatusCode::CONFLICT, &e.to_string());
        }
    }
    if action=="quack" && !["random","single","double","long"].contains(&v["voice"].as_str().unwrap_or("random")) {
        return error(StatusCode::BAD_REQUEST,"无效叫声类型");
    }
    let command = json!({"action":action,"calibration":cal,"id":v["id"],"angleDeg":v["angleDeg"],"voice":v["voice"]});
    let rx = match owner.submit(command, permit) {
        Ok(rx) => rx,
        Err(e) => return error(StatusCode::CONFLICT, &e.to_string()),
    };
    match rx.await {
        Ok(Ok(v)) => Json(v).into_response(),
        Ok(Err(e)) => error(StatusCode::CONFLICT, &e.to_string()),
        Err(_) => error(StatusCode::SERVICE_UNAVAILABLE, "舵机服务已退出"),
    }
}
async fn logs(State(a): State<App>, Query(q): Query<BTreeMap<String, String>>) -> Response {
    if q.get("cursor").is_some_and(|v| v.parse::<u64>().is_err())
        || q.get("limit").is_some_and(|v| v.parse::<usize>().is_err())
    {
        return error(StatusCode::UNPROCESSABLE_ENTITY, "Invalid log query");
    }
    let cursor = q
        .get("cursor")
        .and_then(|v| v.parse::<u64>().ok())
        .unwrap_or(0);
    let limit = q
        .get("limit")
        .and_then(|v| v.parse::<usize>().ok())
        .unwrap_or(200);
    if !(1..=2000).contains(&limit) {
        return error(StatusCode::UNPROCESSABLE_ENTITY, "Invalid limit");
    }
    let s = a.telemetry.read().unwrap();
    let items: Vec<Value> = s
        .logs
        .iter()
        .filter(|v| v["seq"].as_u64().unwrap() > cursor)
        .take(limit)
        .map(|v| s.stamp(v))
        .collect();
    let next = items
        .last()
        .map(|v| v["seq"].as_u64().unwrap())
        .unwrap_or(cursor);
    Json(json!({"items":items,"nextCursor":next,"gap":cursor>0&&s.logs.front().is_some_and(|v|cursor<v["seq"].as_u64().unwrap()-1)})).into_response()
}
async fn scenario(State(a): State<App>, Json(v): Json<Value>) -> Response {
    if a.hardware {
        return error(
            StatusCode::NOT_FOUND,
            "Simulator controls are unavailable on hardware",
        );
    }
    let name = v["name"].as_str().unwrap_or("");
    if !["motion", "steady", "imu_pause", "invalid", "log_burst"].contains(&name) {
        return error(StatusCode::UNPROCESSABLE_ENTITY, "Invalid scenario");
    }
    let mut s = a.telemetry.write().unwrap();
    if name == "log_burst" {
        for i in 0..100 {
            s.log(
                if i % 5 == 0 { "WARN" } else { "INFO" },
                "scenario",
                &format!("日志压力场景 · 事件 {}", i + 1),
            );
        }
    } else {
        s.scenario = name.into();
    }
    s.log("INFO", "scenario", &format!("切换场景：{name}"));
    Json(json!({"scenario":name})).into_response()
}
async fn policy_info(State(a): State<App>) -> Json<Value> {
    let s = a.telemetry.read().unwrap();
    let meta = policy::metadata_for("xgoduck");
    let models: Vec<Value> = ["swizzle_prepare","swizzle","swizzle_crouch","xgoduck","xgoduck_getup","xgoduck_pick","xgoduck_roulade","kick_left","kick_right","dance10","sitstand_sit","sitstand_stand","flamingo_hold","flamingo_lower"].iter().map(|kind| {
        let metadata=policy::metadata_for(kind);
        let gains=gains::current();
        json!({"kind":kind,"policy":policy::model_id(kind),"available":metadata.is_some(),"metadata":metadata,"runtimeGains":{"p":gains.p,"d":gains.d,"source":"model-gains.json","appliesOn":"next-model-start"}})
    }).collect();
    Json(
        json!({"webHeadControl":true,"available":meta.is_some(),"policy":"xgoduck_walk","kind":"xgoduck","controlHz":50,"metadata":meta,"models":models,"skillActions":["roller_crouch","getup","pick","roulade","sit","standup","kick_left","kick_right","dance","flamingo"],"control":if a.servo{s.control.clone()}else{Value::Null}}),
    )
}
async fn pad_bindings_info()->Json<Value>{Json(pad_bindings::info())}
async fn pad_bindings_update(State(a):State<App>,headers:HeaderMap,body:Bytes)->Response {
    let body=match check_write(&headers,&body,4096){Ok(v)=>v,Err(r)=>return r};
    let permit=match a.gate.clone().try_acquire_owned(){Ok(p)=>p,Err(_)=>return error(StatusCode::CONFLICT,"请先停止模型及其他控制任务")};
    if !model_registry::idle(a.telemetry.read().unwrap().control["state"].as_str().unwrap_or("")){return error(StatusCode::CONFLICT,"请先停止模型及其他控制任务");}
    match tokio::task::spawn_blocking(move||{let _permit=permit;pad_bindings::update(&body)}).await {
        Ok(Ok(v))=>Json(v).into_response(),Ok(Err(e))=>error(StatusCode::CONFLICT,&format!("手柄配置未更改：{e:#}")),
        Err(e)=>error(StatusCode::INTERNAL_SERVER_ERROR,&format!("手柄配置保存失败：{e}")),
    }
}
async fn model_registry_info() -> Response {
    match tokio::task::spawn_blocking(model_registry::snapshot).await {
        Ok(value)=>Json(value).into_response(),
        Err(e)=>error(StatusCode::INTERNAL_SERVER_ERROR,&format!("读取模型列表失败：{e}")),
    }
}
async fn model_registry_action(State(a): State<App>, Path(action): Path<String>, headers: HeaderMap, body: Bytes) -> Response {
    if !matches!(action.as_str(),"select"|"rollback"|"import") {return error(StatusCode::NOT_FOUND,"未知模型管理操作");}
    let body=match check_write(&headers,&body,model_registry::MAX_REQUEST_BYTES) {Ok(v)=>v,Err(r)=>return r};
    let permit=match a.gate.clone().try_acquire_owned() {Ok(p)=>p,Err(_)=>return error(StatusCode::CONFLICT,"请先停止模型及其他控制任务")};
    if !model_registry::idle(a.telemetry.read().unwrap().control["state"].as_str().unwrap_or("")) {
        return error(StatusCode::CONFLICT,"请先停止模型及其他控制任务");
    }
    // The permit lives in the blocking task even if the HTTP client disconnects.
    match tokio::task::spawn_blocking(move || {let _permit=permit;model_registry::update(&action,&body)}).await {
        Ok(Ok(v))=>Json(v).into_response(),
        Ok(Err(e))=>error(StatusCode::CONFLICT,&format!("模型配置未更改：{e:#}")),
        Err(e)=>error(StatusCode::INTERNAL_SERVER_ERROR,&format!("模型管理任务失败：{e}")),
    }
}
async fn model_gains_info() -> Json<Value> {
    let value=gains::ui_current();
    Json(json!({"supported":true,"p":value.p,"d":value.d,"appliesOn":"next-model-start","scope":"all-models","source":"model-gains.json"}))
}
#[cfg(test)]
mod gain_route_tests {
    use super::*;
    #[tokio::test]
    async fn registry_changes_share_motion_gate_and_reject_active_or_unknown_states() {
        let tmp=tempfile::tempdir().unwrap();
        let shared=Arc::new(std::sync::RwLock::new(Telemetry::new(false)));
        let app=App {telemetry:shared.clone(),cal:Arc::new(Mutex::new(Calibration::open(tmp.path().join("cal.json")).unwrap())),topics:BTreeMap::new(),hardware:false,servo:false,tof:false,owner:None,gate:Arc::new(tokio::sync::Semaphore::new(1)),input_gate:Arc::new(tokio::sync::Semaphore::new(1)),plans:Arc::new(Mutex::new(None)),shutdown:Arc::new(AtomicBool::new(false)),gamepad_debug:Arc::new(AtomicBool::new(true))};
        let mut headers=HeaderMap::new();headers.insert("content-type","application/json".parse().unwrap());
        for state in ["policy","moving","preflight","disabling","calibrating",""] {
            shared.write().unwrap().control=json!({"state":state});
            assert_eq!(pad_bindings_update(State(app.clone()),headers.clone(),Bytes::from_static(b"{}")).await.status(),StatusCode::CONFLICT);
            for action in ["select","rollback","import"] {
                let result=model_registry_action(State(app.clone()),Path(action.into()),headers.clone(),Bytes::from_static(b"{}")).await;
                assert_eq!(result.status(),StatusCode::CONFLICT);
            }
        }
        shared.write().unwrap().control=json!({"state":"idle"});
        let _permit=app.gate.clone().acquire_owned().await.unwrap();
        assert_eq!(model_registry_action(State(app.clone()),Path("select".into()),headers,Bytes::from_static(b"{}")).await.status(),StatusCode::CONFLICT);
    }
    #[tokio::test]
    async fn quack_route_is_registered_and_requires_real_hardware() {
        let tmp=tempfile::tempdir().unwrap();
        let shared=Arc::new(std::sync::RwLock::new(Telemetry::new(false)));
        let app=App {telemetry:shared,cal:Arc::new(Mutex::new(Calibration::open(tmp.path().join("cal.json")).unwrap())),topics:BTreeMap::new(),hardware:false,servo:false,tof:false,owner:None,gate:Arc::new(tokio::sync::Semaphore::new(1)),input_gate:Arc::new(tokio::sync::Semaphore::new(1)),plans:Arc::new(Mutex::new(None)),shutdown:Arc::new(AtomicBool::new(false)),gamepad_debug:Arc::new(AtomicBool::new(true))};
        let mut headers=HeaderMap::new();headers.insert("content-type","application/json".parse().unwrap());
        let response=policy_action(State(app),Path("quack".into()),headers,Bytes::from_static(b"{}" )).await;
        assert_eq!(response.status(),StatusCode::CONFLICT);
    }
    #[tokio::test]
    async fn active_control_cannot_save_new_gains() {
        let tmp=tempfile::tempdir().unwrap();
        let shared=Arc::new(std::sync::RwLock::new(Telemetry::new(false)));
        let app=App {telemetry:shared.clone(),cal:Arc::new(Mutex::new(Calibration::open(tmp.path().join("cal.json")).unwrap())),topics:BTreeMap::new(),hardware:false,servo:false,tof:false,owner:None,gate:Arc::new(tokio::sync::Semaphore::new(1)),input_gate:Arc::new(tokio::sync::Semaphore::new(1)),plans:Arc::new(Mutex::new(None)),shutdown:Arc::new(AtomicBool::new(false)),gamepad_debug:Arc::new(AtomicBool::new(true))};
        let mut headers=HeaderMap::new();headers.insert("content-type","application/json".parse().unwrap());
        for state in ["policy","moving","preflight","disabling"] {
            shared.write().unwrap().control=json!({"state":state});
            let response=model_gains(State(app.clone()),headers.clone(),Bytes::from_static(b"{\"p\":8,\"d\":24}")).await;
            assert_eq!(response.status(),StatusCode::CONFLICT);
        }
        shared.write().unwrap().control=json!({"state":"disabled"});
        let _permit=app.gate.clone().acquire_owned().await.unwrap();
        assert_eq!(model_gains(State(app.clone()),headers,Bytes::from_static(b"{\"p\":8,\"d\":24}")).await.status(),StatusCode::CONFLICT);
    }
}
async fn model_gains(State(a): State<App>, headers: HeaderMap, body: Bytes) -> Response {
    let v = match check_write(&headers, &body, 1024) { Ok(v) => v, Err(r) => return r };
    let value = match gains::parse(&v) { Ok(v) => v, Err(e) => return error(StatusCode::BAD_REQUEST, &e.to_string()) };
    let _permit = match a.gate.clone().try_acquire_owned() { Ok(p) => p, Err(_) => return error(StatusCode::CONFLICT, "请先停止模型，再保存增益") };
    let state = a.telemetry.read().unwrap().control["state"].as_str().unwrap_or("").to_owned();
    if matches!(state.as_str(), "policy"|"moving"|"preflight"|"disabling") { return error(StatusCode::CONFLICT, "请先停止模型，再保存增益"); }
    match gains::save_ui(value) {
        Ok(()) => Json(json!({"saved":true,"gains":{"p":value.p,"d":value.d},"appliesOn":"next-model-start","scope":"all-models","source":"model-gains.json"})).into_response(),
        Err(e) => error(StatusCode::INTERNAL_SERVER_ERROR, &format!("保存失败：{e}")),
    }
}
fn policy_home_command(kind:&str,cal:Value)->anyhow::Result<Value> {
    let targets=policy::home_targets_for(kind)?;
    let gains=gains::current();
    Ok(json!({"action":"stand","calibration":cal,"standTargets":targets,"policy":policy::model_id(kind),"kind":kind,"requireUpright":true,"nativePolicyGains":[gains.p,gains.d]}))
}
fn policy_drive_command(shared: &mut Telemetry, body: &Value) -> Response {
        let twist=match if shared.control["activeSkill"]==swizzle::ACTIVE {swizzle::command(body)} else {policy::drive_twist(body)} { Ok(v)=>v, Err(e)=>return error(StatusCode::BAD_REQUEST,&e.to_string()) };
        let head=match head_control::parse(&body) { Ok(v)=>v, Err(e)=>return error(StatusCode::BAD_REQUEST,&e.to_string()) };
        let has_head=body.get("headPitch").is_some() || body.get("headYaw").is_some();
        let Some(sequence)=body["sequence"].as_u64() else { return error(StatusCode::BAD_REQUEST,"缺少行走指令序号"); };
        if shared.control["state"]!="policy" || shared.control["kind"]!="xgoduck" {
            return error(StatusCode::CONFLICT,"请先启动XgoDuck零速度平衡，等待预备姿势完成");
        }
        if shared.control["feedbackHolding"]==true {
            let message = if shared.control["policyPhase"]=="imu-hold" {
                "IMU数据暂时过期，行走已暂停；恢复后请松开并重新按住方向"
            } else {
                "舵机反馈暂缺，行走已暂停；恢复后请松开并重新按住方向"
            };
            return error(StatusCode::CONFLICT,message);
        }
        if (twist!=[0.;3] || head!=[0.;2]) && shared.drive.as_ref().is_some_and(|d|d.session==body["session"].as_str().unwrap_or("") && sequence>d.sequence) {
            shared.cancel_demo("人工摇杆接管",true);
        }
        if shared.autonomy.recovering(){return error(StatusCode::CONFLICT,"自主起身中，仅停止、卸力或关闭自主可中断");}
        shared.autonomous_input(body["session"].as_str().unwrap_or(""),sequence,twist!=[0.;3] || head!=[0.;2]);
        let seated_head=(shared.control["activeSkill"]==swizzle::CROUCH && twist==[0.;3] && head==[0.;2]) || matches!(shared.control["activeSkill"].as_str(),Some("sitstand_sit"|"swizzle_prepare")) && head_control::ready(&shared.control) && twist==[0.;3];
        if shared.control["activeSkill"]=="sitstand_sit" && !seated_head {
            return error(StatusCode::CONFLICT,"坐姿维持中，请先执行站起，再按住方向行走");
        }
        if shared.pending_skill.is_some() || shared.control["activeSkill"].as_str().is_some_and(|kind|kind!="xgoduck" && kind!=swizzle::ACTIVE && !seated_head) {
            return error(StatusCode::CONFLICT,"动作执行中，方向指令暂不可用");
        }
        if has_head && head != [0.;2] && !head_control::ready(&shared.control) {
            return error(StatusCode::CONFLICT,"当前模型不支持头部控制");
        }
        let Some(drive)=shared.drive.as_mut() else { return error(StatusCode::CONFLICT,"行走会话已结束"); };
        if !drive.update(body["session"].as_str().unwrap_or(""),sequence,twist) {
            return error(StatusCode::CONFLICT,"行走会话或指令序号已过期");
        }
        // Apply only after the shared session/sequence accepted the body command.
        // Legacy BLE renewals omit these fields and retain their own head intent.
        if has_head { shared.head_intent.set(head); }
        Json(json!({"state":"commanded","twist":twist,"sequence":sequence})).into_response()
}
async fn policy_action(
    State(a): State<App>,
    Path(action): Path<String>,
    h: HeaderMap,
    b: Bytes,
) -> Response {
    if !["start", "stop", "shadow", "home", "command", "skill", "mouth", "quack", "demo", "autonomy"].contains(&action.as_str()) {
        return error(StatusCode::NOT_FOUND, "Not Found");
    }
    let body = match check_action(&h, &b, 1024) {
        Ok(v) => v,
        Err(r) => return r,
    };
    let Some(owner) = a.owner.as_ref().filter(|_| a.hardware) else {
        return error(StatusCode::CONFLICT, "需要实机传感器与舵机服务");
    };
    if action == "stop" {
        let mut shared=a.telemetry.write().unwrap();shared.drive=None;shared.pending_skill=None;
        shared.cancel_demo("停止模型",false);
        shared.stop_autonomy("用户停止模型",false);
        owner.halt.store(true, Ordering::Release);
        return Json(json!({"state":"stopping","message":"停止模型请求已发送，保持最后目标"}))
            .into_response();
    }
    if action=="autonomy" {
        let session=body["session"].as_str().unwrap_or("");
        let Some(sequence)=body["sequence"].as_u64() else {return error(StatusCode::BAD_REQUEST,"缺少自主指令序号");};
        let enabling=!a.telemetry.read().unwrap().autonomy.enabled();
        if enabling {
            if policy::metadata_for("xgoduck_getup").is_none(){return error(StatusCode::CONFLICT,"自主模式需要已就绪的起身模型");}
            if let Err(e)=quack::ready(){return error(StatusCode::CONFLICT,&e.to_string());}
        }
        let mut state=a.telemetry.write().unwrap();
        if !state.drive.as_ref().is_some_and(|d|d.session==session && sequence>d.sequence){return error(StatusCode::CONFLICT,"自主会话或序号已过期");}
        if state.autonomy.enabled(){
            state.cancel_vision_sound();
            let recovering=state.autonomy.recovering();state.autonomy.stop("用户关闭自主");
            if recovering {state.autonomy_notice=Some("auto_off");owner.cancel.store(true,Ordering::Release);}
            else {state.quack_cancel=true;state.pending_quack=true;state.quack_voice="auto_off".into();}
        } else {
            let allowed=state.control["state"]=="policy" && state.control["activeSkill"]=="xgoduck" && state.control["runtimeProfile"]=="kissqy-sync50-v1" && state.control["feedbackHolding"]!=true && !state.demo.active && state.pending_skill.is_none() && !state.pending_quack && !state.quack_running && state.drive.as_ref().unwrap().current()==[0.;3] && state.head_intent.current(Instant::now())==[0.;2];
            let result=if allowed {state.autonomy.start(session,Instant::now())}else{Err(anyhow::anyhow!("请先稳定站立、摇杆回中并结束其它动作"))};
            if let Err(e)=result {
                if state.control["state"]=="policy" && !state.pending_quack && !state.quack_running {state.pending_quack=true;state.quack_voice="auto_reject".into();}
                return error(StatusCode::CONFLICT,&e.to_string());
            }
            state.pending_quack=true;state.quack_voice="auto_on".into();
        }
        state.drive.as_mut().unwrap().sequence=sequence;
        state.log("INFO","autonomy",if enabling {"自主模式开启：原地待命"}else{"自主模式关闭"});
        return Json(state.autonomy.status()).into_response();
    }
    if action=="demo" {
        let session=body["session"].as_str().unwrap_or("");
        let Some(sequence)=body["sequence"].as_u64() else {return error(StatusCode::BAD_REQUEST,"缺少演示指令序号");};
        let mode=body["mode"].as_str().unwrap_or("toggle");
        if !["toggle","keepalive","cancel"].contains(&mode) {return error(StatusCode::BAD_REQUEST,"无效演示指令");}
        if mode=="toggle" && !a.telemetry.read().unwrap().demo.active {
            for kind in ["sitstand_sit","sitstand_stand","xgoduck_pick","dance10"] {
                if policy::metadata_for(kind).is_none() {return error(StatusCode::CONFLICT,"演示所需动作模型不可用");}
            }
            if let Err(e)=quack::ready() {return error(StatusCode::CONFLICT,&e.to_string());}
        }
        let mut state=a.telemetry.write().unwrap();
        if !state.drive.as_ref().is_some_and(|d|d.session==session && sequence>d.sequence) {return error(StatusCode::CONFLICT,"演示会话或序号已过期");}
        if mode=="cancel" || (mode=="toggle" && state.demo.active) {state.cancel_demo("用户取消演示",true);}
        else if mode=="keepalive" {state.demo.renew(session,Instant::now());}
        else {
            if state.control["state"]!="policy" || state.control["activeSkill"]!="xgoduck" || state.control["runtimeProfile"]!="kissqy-sync50-v1" || state.control["feedbackHolding"]==true || state.pending_skill.is_some() || state.pending_quack || state.quack_running || state.drive.as_ref().unwrap().current()!=[0.;3] || state.head_intent.current(Instant::now())!=[0.;2] {
                return error(StatusCode::CONFLICT,"请先站立并等待稳定、摇杆回中、其它动作结束");
            }
            if state.autonomy.recovering(){return error(StatusCode::CONFLICT,"自主起身中，普通动作暂不可用");}
            state.cancel_vision_sound();state.autonomy.action(Instant::now());
            if let Err(e)=state.demo.start(session,Instant::now()) {return error(StatusCode::CONFLICT,&e.to_string());}
        }
        state.drive.as_mut().unwrap().sequence=sequence;
        return Json(state.demo.status()).into_response();
    }
    if action=="skill" {
        let mut kind=if body["skill"].as_str().is_some_and(model_registry::is_custom) {body["skill"].as_str().unwrap()} else {match policy::skill_kind(&body["skill"]) {Ok(v)=>v,Err(e)=>return error(StatusCode::BAD_REQUEST,&e.to_string())}};
        if body["skill"]=="flamingo" && a.telemetry.read().unwrap().control["activeSkill"]=="flamingo_hold" {kind="flamingo_lower";}
        if policy::metadata_for(kind).is_none() {return error(StatusCode::CONFLICT,"动作模型不可用");}
        let Some(sequence)=body["sequence"].as_u64() else {return error(StatusCode::BAD_REQUEST,"缺少动作序号");};
        let mut shared=a.telemetry.write().unwrap();
        if !shared.queue_skill(body["session"].as_str().unwrap_or(""),sequence,kind) {
            shared.log("WARN","policy-request",&format!("动作请求拒绝：{kind}，sequence={sequence}，会话/序号或动作/反馈未就绪"));
            return error(StatusCode::CONFLICT,"动作会话/序号无效，或当前动作/反馈尚未就绪");
        }
        shared.log("INFO","policy-request",&format!("动作请求已排队：{kind}，sequence={sequence}"));
        return Json(json!({"state":"queued","skill":body["skill"],"sequence":sequence})).into_response();
    }
    if action=="quack" {
        if let Err(e)=quack::ready() {return error(StatusCode::CONFLICT,&e.to_string());}
        let Some(sequence)=body["sequence"].as_u64() else {return error(StatusCode::BAD_REQUEST,"缺少指令序号");};
        let voice=body["voice"].as_str().unwrap_or("random");
        if !["random","single","double","long"].contains(&voice) {return error(StatusCode::BAD_REQUEST,"无效叫声类型");}
        let mut shared=a.telemetry.write().unwrap();
        if !shared.queue_quack(body["session"].as_str().unwrap_or(""),sequence) {return error(StatusCode::CONFLICT,"嘴部动作正在执行，或会话/反馈尚未就绪");}
        shared.quack_voice=voice.into();
        return Json(json!({"state":"queued","message":"嘎一下已请求"})).into_response();
    }
    if action=="mouth" {
        let Some(degrees)=body["angleDeg"].as_f64().filter(|v|v.is_finite() && (-5. ..=30.).contains(v)) else {return error(StatusCode::BAD_REQUEST,"嘴部角度须为−5–30°");};
        let Some(sequence)=body["sequence"].as_u64() else {return error(StatusCode::BAD_REQUEST,"缺少指令序号");};
        let mut shared=a.telemetry.write().unwrap();
        if !shared.queue_mouth(body["session"].as_str().unwrap_or(""),sequence,degrees) {return error(StatusCode::CONFLICT,"嘴部会话/序号无效，或动作/反馈尚未就绪");}
        return Json(json!({"state":"queued","angleDeg":degrees})).into_response();
    }
    if action == "command" {
        return policy_drive_command(&mut a.telemetry.write().unwrap(), &body);
    }
    let (kind, speed) = match policy::request_profile(&body) {
        Ok(profile) => profile,
        Err(e) => return error(StatusCode::BAD_REQUEST, &e.to_string()),
    };
    if action!="shadow" {
        let s=a.telemetry.read().unwrap();
        if matches!(kind,swizzle::ACTIVE|swizzle::CROUCH) {return error(StatusCode::CONFLICT,"请先卸力并进入轮滑安装姿势，再按A启动");}
        if kind==swizzle::PREPARE && (action!="start" || !swizzle::preparation_idle(&s.control)) {
            return error(StatusCode::CONFLICT,"轮滑预备只能在已卸力状态启动");
        }
        if swizzle::control_mode(&s.control) {return error(StatusCode::CONFLICT,"轮滑模式中，先卸力并拆轮再启动普通动作");}
    }
    if action=="home" && matches!(kind,"xgoduck_getup"|"sitstand_stand") {return error(StatusCode::BAD_REQUEST,"起身从当前姿态启动，不使用站立HOME");}
    let permit = match a.gate.clone().try_acquire_owned() {
        Ok(p) => p,
        Err(_) => return error(StatusCode::CONFLICT, "已有标定或运动任务正在执行"),
    };
    let boot = a.telemetry.read().unwrap().boot.clone();
    let cal = a.cal.lock().unwrap().read(&boot);
    if body["revision"] != cal["revision"] {
        return error(StatusCode::CONFLICT, "标定已更新，请刷新后重试");
    }
    let mut command = if action == "home" {
        match policy_home_command(kind,cal) {Ok(command)=>command,Err(e)=>return error(StatusCode::CONFLICT,&e.to_string())}
    } else {
        json!({"action":"policy","calibration":cal,"shadow":action=="shadow","kind":kind,"speed":speed})
    };
    let drive_session=uuid::Uuid::new_v4().to_string();
    if action=="start" {
        command["driveSession"]=json!(drive_session);
        {let mut state=a.telemetry.write().unwrap();state.pending_skill=None;state.pending_mouth=None;state.mouth_degrees=0.;}
        a.telemetry.write().unwrap().drive = if policy::is_xgoduck(kind) { Some(crate::telemetry::DriveCommand {
            session:drive_session.clone(),sequence:0,twist:[0.;3],updated:Instant::now(),
        }) } else {None};
    }
    let rx = match owner.submit(command, Some(permit)) {
        Ok(rx) => rx,
        Err(e) => return error(StatusCode::CONFLICT, &e.to_string()),
    };
    if action == "start" {
        tokio::spawn(async move {
            let _ = rx.await;
        });
        return Json(
            json!({"state":"preflight","policy":policy::model_id(kind),"kind":kind,"driveSession":drive_session,"message":if matches!(kind,"xgoduck_getup"|"sitstand_sit"|"sitstand_stand") {"动作模型启动，从当前姿态对齐使能后推理"} else {"模型启动，先过渡到所选模型姿势，再持续推理"}}),
        )
        .into_response();
    }
    match rx.await {
        Ok(Ok(v)) => Json(v).into_response(),
        Ok(Err(e)) => error(StatusCode::CONFLICT, &e.to_string()),
        Err(_) => error(StatusCode::SERVICE_UNAVAILABLE, "舵机服务已退出"),
    }
}
async fn stream(State(a): State<App>, h: HeaderMap, ws: WebSocketUpgrade) -> Response {
    if let Some(origin) = h.get("origin") {
        let host = h.get("host").and_then(|h| h.to_str().ok()).unwrap_or("");
        if ![
            format!("http://{host}"),
            "http://localhost:5173".into(),
            "http://127.0.0.1:5173".into(),
        ]
        .iter()
        .any(|s| origin.to_str().ok() == Some(s))
        {
            return error(StatusCode::FORBIDDEN, "Origin not allowed");
        }
    }
    ws.on_upgrade(move |socket| client(socket, a))
        .into_response()
}
async fn send(ws: &mut WebSocket, v: Value) -> bool {
    matches!(
        tokio::time::timeout(
            Duration::from_secs(2),
            ws.send(Message::Text(v.to_string().into()))
        )
        .await,
        Ok(Ok(()))
    )
}
async fn shutdown_signal(a: App) {
    #[cfg(unix)]
    {
        let mut terminate =
            tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
                .expect("SIGTERM handler");
        tokio::select! {_=tokio::signal::ctrl_c()=>{},_=terminate.recv()=>{}}
    }
    #[cfg(not(unix))]
    {
        let _ = tokio::signal::ctrl_c().await;
    }
    if let Some(owner) = &a.owner {
        owner.cancel.store(true, Ordering::Release);
    }
    a.shutdown.store(true, Ordering::Release);
    camera::shutdown().await;
    tof::shutdown().await;
}
async fn api_errors(request: axum::extract::Request, next: axum::middleware::Next) -> Response {
    if request.method()!=Method::GET && observer_ota::busy(&observer_ota::status()) && request.uri().path()!="/api/v1/servos/disable" {
        return error(StatusCode::CONFLICT,"服务正在更新，请等待完成；急停卸力仍可用");
    }
    let api = request.uri().path().starts_with("/api/");
    let response = next.run(request).await;
    if api && response.status() == StatusCode::NOT_FOUND {
        return error(StatusCode::NOT_FOUND, "Not Found");
    };
    response
}
async fn client(mut ws: WebSocket, a: App) {
    let v = match tokio::time::timeout(Duration::from_secs(5), ws.recv()).await {
        Ok(Some(Ok(Message::Text(t)))) => serde_json::from_str::<Value>(&t).unwrap_or(Value::Null),
        _ => return,
    };
    if v["type"] != "subscribe" || !v["topics"].is_object() {
        let _ = ws
            .send(Message::Close(Some(axum::extract::ws::CloseFrame {
                code: 1008,
                reason: "Invalid subscription".into(),
            })))
            .await;
        return;
    }
    let mut rates = BTreeMap::new();
    for (t, r) in v["topics"].as_object().unwrap() {
        if !a.topics.contains_key(t) {
            continue;
        }
        if t == "logs" {
            rates.insert(t.clone(), None);
        } else if let Some(r) = r.as_f64().filter(|r| *r > 0.) {
            rates.insert(t.clone(), Some(r.min(a.topics[t].as_f64().unwrap())));
        }
    }
    let boot = a.telemetry.read().unwrap().boot.clone();
    if !send(&mut ws,json!({"type":"subscribed","protocolVersion":1,"bootId":boot,"requestId":v["requestId"],"topics":rates})).await{return}
    let mut sent: BTreeMap<String, u64> = BTreeMap::new();
    let mut deadlines: BTreeMap<String, Instant> = BTreeMap::new();
    let mut heartbeat = Instant::now();
    let mut timer = tokio::time::interval(Duration::from_millis(10));
    timer.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        tokio::select! {incoming=ws.recv()=>match incoming{None|Some(Err(_))|Some(Ok(Message::Close(_)))=>break,Some(Ok(Message::Ping(p)))=>{if ws.send(Message::Pong(p)).await.is_err(){break}},_=>{}},_=timer.tick()=>{if a.shutdown.load(Ordering::Acquire){break;}let now=Instant::now();if now>=heartbeat{if !send(&mut ws,json!({"type":"heartbeat","bootId":boot})).await{break}heartbeat=now+Duration::from_secs(2);}let mut messages=vec![];{let s=a.telemetry.read().unwrap();for(t,r)in &rates{let old=*sent.get(t).unwrap_or(&0);if t=="logs"{let batch:Vec<Value>=s.logs.iter().filter(|v|v["seq"].as_u64().unwrap()>old).take(100).map(|v|s.stamp(v)).collect();if let Some(last)=batch.last(){sent.insert(t.clone(),last["seq"].as_u64().unwrap());messages.push(json!({"type":"log_batch","gap":old>0&&batch[0]["seq"].as_u64().unwrap()>old+1,"items":batch}));}}else if deadlines.get(t).map_or(true,|d|now>=*d){if let Some(i)=s.latest.get(t){let n=i["seq"].as_u64().unwrap();if n>old{messages.push(s.stamp(i));sent.insert(t.clone(),n);deadlines.insert(t.clone(),deadlines.get(t).copied().unwrap_or(now).checked_add(Duration::from_secs_f64((1./r.unwrap()).min(3153600000.))).unwrap_or(now).max(now));}}}}}for m in messages{if !send(&mut ws,m).await{return}}}}
    }
}
#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.get(1).is_some_and(|s|s=="--benchmark-rear-fk") {
        let path=args.get(2).ok_or_else(||anyhow::anyhow!("Fixture path required"))?;
        println!("{}",rear_hook::benchmark_fixture(std::path::Path::new(path))?);return Ok(());
    }
    if args.get(1).is_some_and(|s| s == "--generate-quack") {
        let dir = args.get(2).ok_or_else(||anyhow::anyhow!("Output directory required"))?;
        let seed = match args.get(3) { Some(s) => s.parse::<u32>()?, None => microduck_sounds::hardware_seed()? };
        println!("{}", quack::generate(std::path::Path::new(dir), seed)?);
        return Ok(());
    }
    gains::init()?;
    model_registry::init()?;
    pad_bindings::init()?;
    if args.get(1).is_some_and(|s|s=="--verify-gamepad") {
        println!("{}",gamepad::verify_input()?);return Ok(());
    }
    if args.get(1).is_some_and(|s|s=="--verify-model-bank") {
        println!("{}",policy::verify_model_bank()?);return Ok(());
    }
    if args.get(1).is_some_and(|s| s == "--verify-policy-fixture") {
        let path = args
            .get(2)
            .ok_or_else(|| anyhow::anyhow!("Fixture path required"))?;
        println!("{}", policy::verify_fixture(std::path::Path::new(path))?);
        return Ok(());
    }
    let env = |k: &str, d: &str| std::env::var(k).unwrap_or(d.into());
    let source = env("MICRODUCK_SOURCE", "simulation");
    if !["simulation", "hardware"].contains(&source.as_str()) {
        anyhow::bail!("Invalid MICRODUCK_SOURCE")
    }
    let hardware = source == "hardware";
    camera::init(hardware).await;
    if hardware {
        let voice_dir = env("MICRODUCK_VOICE_DIR", "/var/lib/microduck-observer/voice");
        if let Err(e) = quack::init(std::path::Path::new(&voice_dir)) { eprintln!("quack voice initialization failed: {e:#}"); }
    }
    if hardware && env("MICRODUCK_IMU_DRIVER", "ms901m") != "ms901m" {
        anyhow::bail!("BNO085 native migration is pending; keep the existing production service")
    };
    let port = env("MICRODUCK_SERVO_PORT", "");
    let tof_enabled = hardware;
    let static_dir = env("MICRODUCK_STATIC_DIR", "../frontend/dist");
    let cal = Calibration::open(PathBuf::from(env(
        "MICRODUCK_CALIBRATION_FILE",
        "./state/calibration.json",
    )))?;
    let shared = Arc::new(RwLock::new(Telemetry::new(hardware)));
    let stop = Arc::new(AtomicBool::new(false));
    if hardware {vision::init(shared.clone(),stop.clone());}
    let gamepad_debug = Arc::new(AtomicBool::new(gamepad::initial_debug()));
    let owner = if !port.is_empty() {
        let ids = env("MICRODUCK_SERVO_IDS", "11,12,13,14,21,22,23,24")
            .split(',')
            .map(|v| v.trim().parse::<u8>())
            .collect::<Result<Vec<_>, _>>()?;
        if ids.is_empty()
            || ids.iter().any(|id| !IDS.contains(id))
            || ids.iter().collect::<std::collections::BTreeSet<_>>().len() != ids.len()
        {
            anyhow::bail!("Servo IDs must be unique configured IDs")
        }
        Some(control::spawn(
            port.clone(),
            ids,
            shared.clone(),
            stop.clone(),
        ))
    } else {
        None
    };
    let a = App {
        telemetry: shared.clone(),
        cal: Arc::new(Mutex::new(cal)),
        topics: rates(hardware, !port.is_empty(), tof_enabled),
        hardware,
        servo: !port.is_empty(),
        tof: tof_enabled,
        owner,
        gate: Arc::new(tokio::sync::Semaphore::new(1)),
        input_gate: Arc::new(tokio::sync::Semaphore::new(1)),
        plans: Arc::new(Mutex::new(None)),
        shutdown: stop.clone(),
        gamepad_debug: gamepad_debug.clone(),
    };
    if hardware {observer_ota::startup_lock(a.gate.clone());}
    if hardware {
        resources::spawn(shared.clone(),stop.clone());
        imu::spawn_reader(
            env("MICRODUCK_IMU_PORT", "/dev/ttyS9"),
            shared.clone(),
            stop.clone(),
        );
    }
    tof::init(hardware,shared.clone()).await;
    let data = shared.clone();
    let producer_stop = stop.clone();
    tokio::spawn(async move {
        let mut timer = tokio::time::interval(Duration::from_millis(20));
        timer.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        let mut system = Instant::now() - Duration::from_secs(1);
        loop {
            timer.tick().await;
            if producer_stop.load(Ordering::Acquire) {
                break;
            }
            let mut s = data.write().unwrap();
            if !hardware {
                s.simulate()
            }
            if system.elapsed() >= Duration::from_secs(1) {
                let d = json!({"service":service_version(),"resources":s.resources,"uptimeSeconds":s.started.elapsed().as_secs_f64(),"servoControl":if !port.is_empty(){s.control.clone()}else{Value::Null},"tof":if tof_enabled{s.tof_health()}else{Value::Null},"imu":s.imu_health(),"scenario":if hardware{Value::Null}else{json!(s.scenario)}});
                s.sample("system", d, true, Instant::now());
                system = Instant::now();
            }
        }
    });
    let cors = CorsLayer::new()
        .allow_origin([
            HeaderValue::from_static("http://localhost:5173"),
            HeaderValue::from_static("http://127.0.0.1:5173"),
        ])
        .allow_methods([Method::GET, Method::POST])
        .allow_headers([axum::http::header::CONTENT_TYPE]);
    let shutdown_app = a.clone();
    let ble_app = a.clone();
    let gamepad_app = a.clone();
    let owner = a.owner.clone();
    let router = Router::new()
        .route("/api/v1/info", get(info))
        .route("/api/v1/health", get(health))
        .route("/api/v1/system/{action}", post(power_action))
        .route("/api/v1/snapshot", get(snapshot))
        .route("/api/v1/calibration", get(get_cal).post(set_cal))
        .route("/api/v1/calibration/poses", get(poses))
        .route("/api/v1/servos/limits", get(limits))
        .route("/api/v1/logs", get(logs))
        .route("/api/v1/policy", get(policy_info))
        .route("/api/v1/model-registry", get(model_registry_info))
        .route("/api/v1/model-registry/{action}", post(model_registry_action).layer(DefaultBodyLimit::max(model_registry::MAX_REQUEST_BYTES)))
        .route("/api/v1/model-gains", get(model_gains_info).post(model_gains))
        .route("/api/v1/policy/{action}", post(policy_action))
        .route("/api/v1/servos/{action}", post(servo_action))
        .route("/api/v1/calibration/{action}", post(guided_action))
        .route("/api/v1/debug/scenario", post(scenario))
        .route("/api/v1/stream", get(stream))
        .merge(gamepad::mode_router())
        .route("/api/v1/gamepad/bindings", get(pad_bindings_info).post(pad_bindings_update))
        .merge(gamepad_bluetooth::router())
        .merge(camera::router())
        .merge(tof::router())
        .merge(web_update::router())
        .fallback_service(ServeDir::new(static_dir).append_index_html_on_directories(true))
        .layer(DefaultBodyLimit::max(16384))
        .layer(cors)
        .layer(axum::middleware::from_fn(api_errors))
        .with_state(a);
    if env("MICRODUCK_BLE_ENABLED", "0") == "1" {
        ducklink::spawn(ble_app, router.clone(), stop.clone());
    }
    gamepad::spawn(gamepad_app, router.clone());
    let listener = tokio::net::TcpListener::bind(env("MICRODUCK_BIND", "127.0.0.1:8878")).await?;
    axum::serve(listener, router)
        .with_graceful_shutdown(shutdown_signal(shutdown_app))
        .await?;
    stop.store(true, Ordering::Relaxed);
    if let Some(owner) = owner {
        let deadline = Instant::now() + Duration::from_secs(5);
        while !owner.done.load(Ordering::Acquire) && Instant::now() < deadline {
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    }
    Ok(())
}

#[cfg(test)]
mod web_gamepad_tests {
    use super::*;
    fn ready() -> Telemetry {
        let mut s=Telemetry::new(false);
        s.control=json!({"state":"policy","kind":"xgoduck","activeSkill":"xgoduck","runtimeProfile":"kissqy-sync50-v1"});
        s.drive=Some(telemetry::DriveCommand{session:"web".into(),sequence:0,twist:[0.;3],updated:Instant::now()});s
    }
    #[test] fn autonomous_recovery_blocks_drive_and_manual_skills_without_changing_sequence(){
        let mut s=ready();let now=Instant::now();s.autonomy.observe(now- Duration::from_millis(600),"xgoduck",true,false,false);s.autonomy.observe(now,"xgoduck",true,false,false);s.autonomy.start("web",now).unwrap();s.autonomy.fall(now);
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":1,"twist":[0.2,0,0]})).status(),StatusCode::CONFLICT);
        assert!(!s.queue_skill("web",1,"xgoduck_getup"));assert!(!s.queue_quack("web",1));assert!(!s.queue_mouth("web",1,20.));
        assert_eq!(s.drive.as_ref().unwrap().sequence,0);assert_eq!(s.drive.as_ref().unwrap().twist,[0.;3]);assert!(s.autonomy.recovering());
    }
    #[test] fn foreign_and_replayed_drive_cannot_take_over_autonomy(){
        let mut s=ready();let now=Instant::now();s.autonomy.observe(now-Duration::from_millis(600),"xgoduck",true,false,false);s.autonomy.observe(now,"xgoduck",true,false,false);s.autonomy.start("web",now).unwrap();
        s.vision.sound=true;s.pending_quack=true;
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"other","sequence":1,"twist":[0.2,0,0]})).status(),StatusCode::CONFLICT);assert_eq!(s.autonomy.mode,autonomy::Mode::Standby);
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":0,"twist":[0.2,0,0]})).status(),StatusCode::CONFLICT);assert_eq!(s.autonomy.mode,autonomy::Mode::Standby);
        assert!(s.pending_quack && s.vision.sound);
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":1,"twist":[0.2,0,0]})).status(),StatusCode::OK);assert_eq!(s.autonomy.mode,autonomy::Mode::Manual);
        assert!(!s.pending_quack && !s.vision.sound);assert!(s.quack_cancel);
    }
    #[test]
    fn head_requires_current_session_and_sequence_and_legacy_packets_preserve_it() {
        let mut s=ready();
        let mut body=json!({"session":"web","sequence":1,"twist":[0.1,0,0],"headPitch":0.4,"headYaw":-0.3});
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::OK);
        assert_eq!(s.head_intent.current(Instant::now()),[0.4,-0.3]);
        body["headYaw"]=json!(1);
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        body["sequence"]=json!(2);body["session"]=json!("other");
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        assert_eq!(s.head_intent.current(Instant::now()),[0.4,-0.3]);
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":2,"twist":[0,0,0]})).status(),StatusCode::OK);
        assert_eq!(s.head_intent.current(Instant::now()),[0.4,-0.3]);
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":3,"twist":[0,0,0],"headPitch":0,"headYaw":0})).status(),StatusCode::OK);
        assert_eq!(s.head_intent.current(Instant::now()),[0.,0.]);
    }
    #[test]
    fn seated_head_accepts_only_zero_body_after_settling() {
        let mut s=ready();s.control["activeSkill"]=json!("sitstand_sit");
        s.control["skillProgressSeconds"]=json!(3.9);s.control["sitSettleSeconds"]=json!(4.);
        let mut body=json!({"session":"web","sequence":1,"twist":[0,0,0],"headPitch":0.7,"headYaw":-0.5});
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        s.control["skillProgressSeconds"]=json!(4.);
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::OK);
        assert_eq!(s.head_intent.current(Instant::now()),[0.7,-0.5]);
        body["sequence"]=json!(2);body["twist"]=json!([0.1,0,0]);
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        assert_eq!(s.drive.as_ref().unwrap().sequence,1);
        body["twist"]=json!([0,0,0]);s.control["feedbackHolding"]=json!(true);
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        s.control["feedbackHolding"]=json!(false);s.control["activeSkill"]=json!("sitstand_stand");
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
    }
    #[test]
    fn invalid_or_unready_head_does_not_advance_body_sequence() {
        for value in [json!(2),json!("bad"),Value::Null] {
            let mut s=ready();
            assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":1,"twist":[0.1,0,0],"headPitch":value})).status(),StatusCode::BAD_REQUEST);
            assert_eq!(s.drive.as_ref().unwrap().sequence,0);
        }
        let mut s=ready();s.control["runtimeProfile"]=json!("other");
        assert_eq!(policy_drive_command(&mut s,&json!({"session":"web","sequence":1,"twist":[0.1,0,0],"headYaw":1})).status(),StatusCode::CONFLICT);
        assert_eq!(s.drive.as_ref().unwrap().sequence,0);
    }
}

#[cfg(test)] mod roller_route_tests {
    use super::*;
    #[test] fn crouch_allows_only_zero_cleanup_commands_without_affecting_its_clock() {
        let mut s=Telemetry::new(true);s.control=json!({"state":"policy","kind":"xgoduck","activeSkill":"swizzle_crouch","skillProgressSeconds":1.2});
        s.drive=Some(crate::telemetry::DriveCommand{session:"s".into(),sequence:0,twist:[0.;3],updated:Instant::now()});
        let mut b=json!({"session":"s","sequence":1,"twist":[0,0,0],"headPitch":0,"headYaw":0});
        assert_eq!(policy_drive_command(&mut s,&b).status(),StatusCode::OK);
        b["sequence"]=json!(2);b["twist"]=json!([0.1,0,0]);assert_eq!(policy_drive_command(&mut s,&b).status(),StatusCode::CONFLICT);
        b["twist"]=json!([0,0,0]);b["headYaw"]=json!(0.4);assert_eq!(policy_drive_command(&mut s,&b).status(),StatusCode::CONFLICT);
        assert_eq!(s.control["skillProgressSeconds"],1.2);assert_eq!(s.drive.as_ref().unwrap().sequence,1);
    }
    #[test] fn roller_head_uses_owned_sequence_and_installation_never_accepts_throttle() {
        for skill in ["swizzle_prepare","swizzle"] {
            let mut s=Telemetry::new(true);
            s.control=json!({"state":"policy","kind":"xgoduck","activeSkill":skill,"runtimeProfile":"kissqy-sync50-v1"});
            s.drive=Some(crate::telemetry::DriveCommand{session:"s".into(),sequence:0,twist:[0.;3],updated:Instant::now()});
            let mut body=json!({"session":"other","sequence":1,"twist":[0,0,0],"headPitch":0.4,"headYaw":-0.5});
            assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
            body["session"]=json!("s");assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::OK);
            assert_eq!(s.head_intent.current(Instant::now()),[0.4,-0.5]);
            assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
            body["sequence"]=json!(2);body["twist"]=json!([0.2,0,0]);
            assert_eq!(policy_drive_command(&mut s,&body).status(),if skill=="swizzle"{StatusCode::OK}else{StatusCode::CONFLICT});
            s.control["feedbackHolding"]=json!(true);body["sequence"]=json!(3);body["twist"]=json!([0,0,0]);
            assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        }
    }
    #[test] fn roller_route_checks_heading_units_and_session_without_enabling_preparation_drive() {
        let mut s=Telemetry::new(true);
        s.control=json!({"state":"policy","kind":"xgoduck","activeSkill":"swizzle_prepare"});
        s.drive=Some(crate::telemetry::DriveCommand{session:"s".into(),sequence:0,twist:[0.;3],updated:Instant::now()});
        let mut body=json!({"session":"s","sequence":1,"twist":[-0.4,0,0.25]});
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        s.control["activeSkill"]=json!("swizzle");
        body["twist"]=json!([0,0,1]);assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::BAD_REQUEST);
        body["twist"]=json!([-0.4,0,0.25]);body["session"]=json!("foreign");assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        body["session"]=json!("s");assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::OK);
        assert_eq!(policy_drive_command(&mut s,&body).status(),StatusCode::CONFLICT);
        assert_eq!(s.drive.as_ref().unwrap().twist,[-0.4,0.,0.25]);
    }
}
