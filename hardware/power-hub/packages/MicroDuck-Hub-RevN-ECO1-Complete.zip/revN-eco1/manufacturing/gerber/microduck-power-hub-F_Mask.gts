%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-20T21:44:14+08:00*%
%TF.ProjectId,microduck-power-hub,6d696372-6f64-4756-936b-2d706f776572,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-20 21:44:14*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.225000X-0.525000X-0.525000X0.525000X-0.525000X0.525000X0.525000X-0.525000X0.525000X0*%
%ADD11C,1.500000*%
%ADD12C,3.000000*%
%ADD13RoundRect,0.250000X-0.325000X-0.650000X0.325000X-0.650000X0.325000X0.650000X-0.325000X0.650000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J4*%
X32000000Y-15700000D03*
D11*
X30000000Y-15700000D03*
X28000000Y-15700000D03*
%TD*%
D10*
%TO.C,J2*%
X12000000Y-15700000D03*
D11*
X10000000Y-15700000D03*
X8000000Y-15700000D03*
%TD*%
D12*
%TO.C,J1*%
X4000000Y-4500000D03*
%TD*%
D13*
%TO.C,C1*%
X4525000Y-20100000D03*
X7475000Y-20100000D03*
%TD*%
D12*
%TO.C,J5*%
X36000000Y-4500000D03*
%TD*%
D10*
%TO.C,J3*%
X22000000Y-4500000D03*
D11*
X20000000Y-4500000D03*
X18000000Y-4500000D03*
%TD*%
M02*
